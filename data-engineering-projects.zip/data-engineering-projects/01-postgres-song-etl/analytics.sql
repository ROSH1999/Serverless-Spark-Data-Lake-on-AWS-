-- Example analytics on the Sparkify star schema.
-- Run them with:  psql -h localhost -U student -d sparkify -f analytics.sql

-- Timestamps are stored as TIMESTAMPTZ; show them in UTC rather than your local zone.
SET TIME ZONE 'UTC';

\echo '1. Top 10 most played songs (catalog matches only)'
SELECT s.title, a.name AS artist, COUNT(*) AS plays
FROM songplays sp
JOIN songs s   ON s.song_id = sp.song_id
JOIN artists a ON a.artist_id = sp.artist_id
GROUP BY s.title, a.name
ORDER BY plays DESC, s.title
LIMIT 10;

\echo '2. Listening by hour of day (UTC)'
SELECT t.hour, COUNT(*) AS plays
FROM songplays sp
JOIN time t ON t.start_time = sp.start_time
GROUP BY t.hour
ORDER BY t.hour;

\echo '3. Free vs paid: plays per user'
SELECT sp.level,
       COUNT(*)                              AS plays,
       COUNT(DISTINCT sp.user_id)            AS users,
       ROUND(COUNT(*)::numeric / COUNT(DISTINCT sp.user_id), 1) AS plays_per_user
FROM songplays sp
GROUP BY sp.level;

\echo '4. Users who upgraded from free to paid during the period'
SELECT u.user_id, u.first_name, u.last_name,
       MIN(sp.start_time) FILTER (WHERE sp.level = 'paid') AS first_paid_play
FROM users u
JOIN songplays sp USING (user_id)
GROUP BY u.user_id, u.first_name, u.last_name
HAVING BOOL_OR(sp.level = 'free') AND BOOL_OR(sp.level = 'paid')
ORDER BY first_paid_play;

\echo '5. Catalog coverage: share of plays we can attribute to a known song'
SELECT ROUND(100.0 * COUNT(song_id) / COUNT(*), 1) AS pct_matched
FROM songplays;
