"""(Re)create the Sparkify tables. Destructive: drops existing tables first.

    python create_tables.py
"""

from db import connect
from sql_queries import CREATE_TABLES, DROP_TABLES


def main() -> None:
    with connect() as conn:  # the `with` block commits on success, rolls back on error
        with conn.cursor() as cur:
            for stmt in DROP_TABLES:
                cur.execute(stmt)
            for stmt in CREATE_TABLES:
                cur.execute(stmt)
    print("Tables created: songplays, users, songs, artists, time")


if __name__ == "__main__":
    main()
