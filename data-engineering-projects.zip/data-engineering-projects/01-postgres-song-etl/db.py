"""Small connection helper.

Settings come from the standard libpq environment variables (PGHOST, PGPORT,
PGUSER, PGPASSWORD, PGDATABASE), with defaults that match docker-compose.yml.
"""

import os

import psycopg


def connect(dbname: str | None = None, **kwargs) -> psycopg.Connection:
    return psycopg.connect(
        host=os.getenv("PGHOST", "localhost"),
        port=int(os.getenv("PGPORT", "5432")),
        user=os.getenv("PGUSER", "student"),
        password=os.getenv("PGPASSWORD", "student"),
        dbname=dbname or os.getenv("PGDATABASE", "sparkify"),
        **kwargs,
    )
