"""Load the raw song catalog and activity logs into the Sparkify star schema.

    python create_tables.py     # once (drops and recreates tables)
    python etl.py               # safe to re-run: every insert is an upsert

Steps
-----
1. Extract  – read every JSON file under DATA_DIR/song_data and DATA_DIR/log_data
2. Transform – clean and reshape them into table-shaped DataFrames (transforms.py)
3. Load     – upsert into Postgres in dependency order: artists -> songs ->
              time/users -> songplays (the fact table references the others)
4. Check    – run a few data quality queries and fail loudly if one breaks
"""

from __future__ import annotations

import argparse
import os
import time
from pathlib import Path

import sql_queries as q
import transforms as t
from db import connect

DEFAULT_DATA_DIR = Path(os.getenv("DATA_DIR", Path(__file__).resolve().parents[1] / "data"))


def load(cur, sql: str, rows: list[tuple], label: str) -> None:
    start = time.perf_counter()
    cur.executemany(sql, rows)
    print(f"  {label:<10} {len(rows):>6} rows  ({time.perf_counter() - start:.2f}s)")


def process_song_data(conn, data_dir: Path) -> None:
    files = t.find_json_files(data_dir / "song_data")
    print(f"Song catalog: {len(files)} files")
    song_df = t.read_song_files(files)
    with conn.cursor() as cur:
        load(cur, q.INSERT_ARTIST, t.to_rows(t.artists_table(song_df)), "artists")
        load(cur, q.INSERT_SONG, t.to_rows(t.songs_table(song_df)), "songs")
    conn.commit()


def process_log_data(conn, data_dir: Path) -> None:
    files = t.find_json_files(data_dir / "log_data")
    log_df = t.read_log_files(files)
    events = t.song_play_events(log_df)
    print(f"Activity logs: {len(files)} files, {len(log_df)} events, {len(events)} song plays")

    with conn.cursor() as cur:
        load(cur, q.INSERT_TIME, t.to_rows(t.time_table(events)), "time")
        load(cur, q.INSERT_USER, t.to_rows(t.users_table(events)), "users")

        # Build an in-memory lookup once instead of one SELECT per event.
        cur.execute(q.SONG_LOOKUP)
        lookup = {t.song_key(title, artist, dur): (song_id, artist_id)
                  for title, artist, dur, song_id, artist_id in cur.fetchall()}
        songplays = t.songplays_table(events, lookup)
        matched = songplays["song_id"].notna().sum()
        load(cur, q.INSERT_SONGPLAY, t.to_rows(songplays), "songplays")
        print(f"  {matched}/{len(songplays)} plays matched a song in the catalog")
    conn.commit()


def run_quality_checks(conn) -> None:
    print("Data quality checks:")
    failures = []
    with conn.cursor() as cur:
        for name, sql, check in q.QUALITY_CHECKS:
            cur.execute(sql)
            value = cur.fetchone()[0]
            ok = check(value)
            print(f"  [{'PASS' if ok else 'FAIL'}] {name} (value={value})")
            if not ok:
                failures.append(name)
    if failures:
        raise SystemExit(f"{len(failures)} data quality check(s) failed: {failures}")


def main() -> None:
    parser = argparse.ArgumentParser(description="Load Sparkify JSON data into Postgres")
    parser.add_argument("--data-dir", type=Path, default=DEFAULT_DATA_DIR)
    args = parser.parse_args()
    if not (args.data_dir / "song_data").exists():
        raise SystemExit(f"No data in {args.data_dir}. Run: python shared/generate_sample_data.py")

    with connect() as conn:
        process_song_data(conn, args.data_dir)
        process_log_data(conn, args.data_dir)
        run_quality_checks(conn)
    print("Done.")


if __name__ == "__main__":
    main()
