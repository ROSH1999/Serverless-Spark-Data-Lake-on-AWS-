"""SQL for the Sparkify star schema in Postgres.

Keeping SQL in one module (rather than sprinkled through the ETL) makes it easy
to read the data model in one place and to reuse statements in tests.

Star schema
-----------
fact:        songplays  – one row per song play (page = 'NextSong')
dimensions:  users, songs, artists, time
"""

# ---------------------------------------------------------------- DROP TABLES

DROP_TABLES = [
    "DROP TABLE IF EXISTS songplays",
    "DROP TABLE IF EXISTS users",
    "DROP TABLE IF EXISTS songs",
    "DROP TABLE IF EXISTS artists",
    "DROP TABLE IF EXISTS time",
]

# -------------------------------------------------------------- CREATE TABLES
# Dimensions are created first so the fact table's foreign keys resolve.

CREATE_USERS = """
CREATE TABLE IF NOT EXISTS users (
    user_id     INTEGER PRIMARY KEY,
    first_name  TEXT,
    last_name   TEXT,
    gender      CHAR(1),
    level       TEXT NOT NULL CHECK (level IN ('free', 'paid'))
)
"""

CREATE_ARTISTS = """
CREATE TABLE IF NOT EXISTS artists (
    artist_id   TEXT PRIMARY KEY,
    name        TEXT NOT NULL,
    location    TEXT,
    latitude    DOUBLE PRECISION,
    longitude   DOUBLE PRECISION
)
"""

CREATE_SONGS = """
CREATE TABLE IF NOT EXISTS songs (
    song_id     TEXT PRIMARY KEY,
    title       TEXT NOT NULL,
    artist_id   TEXT NOT NULL REFERENCES artists (artist_id),
    year        SMALLINT,               -- NULL when unknown (source uses 0)
    duration    NUMERIC(10, 5) NOT NULL
)
"""

CREATE_TIME = """
CREATE TABLE IF NOT EXISTS time (
    start_time  TIMESTAMPTZ PRIMARY KEY,
    hour        SMALLINT NOT NULL,
    day         SMALLINT NOT NULL,
    week        SMALLINT NOT NULL,
    month       SMALLINT NOT NULL,
    year        SMALLINT NOT NULL,
    weekday     SMALLINT NOT NULL      -- 0 = Monday ... 6 = Sunday
)
"""

# song_id / artist_id are nullable on purpose: a play is still a play even when
# the song isn't in our catalog. Analysts can count plays per user or per hour
# without losing those rows; song-level reports simply filter them out.
CREATE_SONGPLAYS = """
CREATE TABLE IF NOT EXISTS songplays (
    songplay_id  BIGSERIAL PRIMARY KEY,
    start_time   TIMESTAMPTZ NOT NULL REFERENCES time (start_time),
    user_id      INTEGER NOT NULL REFERENCES users (user_id),
    level        TEXT NOT NULL,
    song_id      TEXT REFERENCES songs (song_id),
    artist_id    TEXT REFERENCES artists (artist_id),
    session_id   INTEGER NOT NULL,
    location     TEXT,
    user_agent   TEXT,
    -- natural key: lets the ETL be re-run without creating duplicates
    CONSTRAINT songplays_natural_key UNIQUE (user_id, session_id, start_time)
)
"""

CREATE_INDEXES = [
    "CREATE INDEX IF NOT EXISTS songplays_start_time_idx ON songplays (start_time)",
    "CREATE INDEX IF NOT EXISTS songplays_song_id_idx ON songplays (song_id)",
    # Used to match log events (title + artist name + duration) to catalog ids.
    "CREATE INDEX IF NOT EXISTS songs_title_idx ON songs (title)",
]

CREATE_TABLES = [CREATE_USERS, CREATE_ARTISTS, CREATE_SONGS, CREATE_TIME, CREATE_SONGPLAYS, *CREATE_INDEXES]

# ---------------------------------------------------------------- UPSERTS
# ON CONFLICT makes every load idempotent: running etl.py twice gives the same
# result as running it once.

INSERT_ARTIST = """
INSERT INTO artists (artist_id, name, location, latitude, longitude)
VALUES (%s, %s, %s, %s, %s)
ON CONFLICT (artist_id) DO UPDATE SET
    name      = EXCLUDED.name,
    location  = COALESCE(EXCLUDED.location, artists.location),
    latitude  = COALESCE(EXCLUDED.latitude, artists.latitude),
    longitude = COALESCE(EXCLUDED.longitude, artists.longitude)
"""

INSERT_SONG = """
INSERT INTO songs (song_id, title, artist_id, year, duration)
VALUES (%s, %s, %s, %s, %s)
ON CONFLICT (song_id) DO NOTHING
"""

INSERT_TIME = """
INSERT INTO time (start_time, hour, day, week, month, year, weekday)
VALUES (%s, %s, %s, %s, %s, %s, %s)
ON CONFLICT (start_time) DO NOTHING
"""

# A user's level changes over time (free -> paid). We keep the latest value,
# i.e. a "Type 1" slowly changing dimension.
INSERT_USER = """
INSERT INTO users (user_id, first_name, last_name, gender, level)
VALUES (%s, %s, %s, %s, %s)
ON CONFLICT (user_id) DO UPDATE SET
    first_name = EXCLUDED.first_name,
    last_name  = EXCLUDED.last_name,
    gender     = EXCLUDED.gender,
    level      = EXCLUDED.level
"""

INSERT_SONGPLAY = """
INSERT INTO songplays (start_time, user_id, level, song_id, artist_id, session_id, location, user_agent)
VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
ON CONFLICT ON CONSTRAINT songplays_natural_key DO NOTHING
"""

# ---------------------------------------------------------------- LOOKUPS

# Log events only carry song title, artist name and duration, so we look up the
# catalog ids by those three attributes.
SONG_LOOKUP = """
SELECT s.title, a.name, s.duration, s.song_id, s.artist_id
FROM songs s
JOIN artists a USING (artist_id)
"""

# ---------------------------------------------------------- QUALITY CHECKS
# (description, sql returning one number, check function)

QUALITY_CHECKS = [
    ("songplays has rows", "SELECT COUNT(*) FROM songplays", lambda n: n > 0),
    ("users has rows", "SELECT COUNT(*) FROM users", lambda n: n > 0),
    ("no songplays without a user", "SELECT COUNT(*) FROM songplays WHERE user_id IS NULL", lambda n: n == 0),
    ("no duplicate plays",
     "SELECT COUNT(*) - COUNT(DISTINCT (user_id, session_id, start_time)) FROM songplays",
     lambda n: n == 0),
    ("levels are valid", "SELECT COUNT(*) FROM users WHERE level NOT IN ('free','paid')", lambda n: n == 0),
]
