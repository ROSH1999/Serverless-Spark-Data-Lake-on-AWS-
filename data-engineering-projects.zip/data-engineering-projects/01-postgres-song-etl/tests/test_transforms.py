"""Unit tests for the pure transform functions. No database needed.

    pytest 01-postgres-song-etl
"""

import sys
from pathlib import Path

import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import transforms as t  # noqa: E402


def song_df():
    return pd.DataFrame(
        [
            {"song_id": "SO1", "title": " Hello ", "artist_id": "AR1", "year": 0, "duration": 200.123,
             "artist_name": "Band", "artist_location": "", "artist_latitude": None, "artist_longitude": None},
            {"song_id": "SO2", "title": "World", "artist_id": "AR1", "year": 1999, "duration": 180.0,
             "artist_name": "Band", "artist_location": "London", "artist_latitude": 51.5, "artist_longitude": -0.1},
            {"song_id": "SO2", "title": "World", "artist_id": "AR1", "year": 1999, "duration": 180.0,
             "artist_name": "Band", "artist_location": "London", "artist_latitude": 51.5, "artist_longitude": -0.1},
        ]
    )


def log_df():
    base = {"artist": "Band", "song": "World", "length": 180.0, "firstName": "Ann", "lastName": "Lee",
            "gender": "F", "location": "NYC", "userAgent": "UA", "sessionId": 7}
    return pd.DataFrame(
        [
            {**base, "page": "NextSong", "userId": "5", "level": "free", "itemInSession": 0, "ts": 1_788_000_000_000},
            {**base, "page": "NextSong", "userId": "5", "level": "free", "itemInSession": 0, "ts": 1_788_000_000_000},
            {**base, "page": "Home", "userId": "5", "level": "free", "itemInSession": 1, "ts": 1_788_000_100_000},
            {**base, "page": "NextSong", "userId": "", "level": "free", "itemInSession": 2, "ts": 1_788_000_200_000},
            {**base, "page": "NextSong", "userId": "5", "level": "paid", "itemInSession": 3, "ts": 1_788_000_300_000,
             "song": "Unknown", "artist": "Nobody"},
        ]
    )


def test_songs_table_dedupes_and_nulls_unknown_year():
    songs = t.songs_table(song_df())
    assert list(songs["song_id"]) == ["SO1", "SO2"]
    assert pd.isna(songs.iloc[0]["year"])
    assert songs.iloc[0]["title"] == "Hello"


def test_artists_table_prefers_known_location():
    artists = t.artists_table(song_df())
    assert len(artists) == 1
    assert artists.iloc[0]["location"] == "London"


def test_song_play_events_filters_and_dedupes():
    events = t.song_play_events(log_df())
    # duplicate removed, Home page removed, logged-out play removed
    assert len(events) == 2
    assert events["user_id"].tolist() == [5, 5]
    assert str(events["start_time"].dt.tz) == "UTC"


def test_users_table_keeps_latest_level():
    users = t.users_table(t.song_play_events(log_df()))
    assert users.to_dict("records") == [
        {"user_id": 5, "first_name": "Ann", "last_name": "Lee", "gender": "F", "level": "paid"}
    ]


def test_time_table_parts():
    time_df = t.time_table(t.song_play_events(log_df()))
    row = time_df.iloc[0]
    assert (row["year"], row["month"]) == (2026, 8)
    assert 0 <= row["weekday"] <= 6


def test_songplays_match_catalog_with_tolerant_key():
    events = t.song_play_events(log_df())
    lookup = {t.song_key("world", "BAND", 180.0001): ("SO2", "AR1")}
    plays = t.songplays_table(events, lookup)
    assert plays["song_id"].iloc[0] == "SO2" and pd.isna(plays["song_id"].iloc[1])
    assert plays["artist_id"].iloc[0] == "AR1" and pd.isna(plays["artist_id"].iloc[1])
    # unmatched plays become SQL NULLs when loaded
    assert t.to_rows(plays)[1][3] is None


def test_to_rows_converts_missing_to_none():
    rows = t.to_rows(pd.DataFrame({"a": [1, None], "b": pd.array([2, None], dtype="Int64")}))
    assert rows == [(1.0, 2), (None, None)]
