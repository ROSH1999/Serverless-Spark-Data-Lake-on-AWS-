"""Pure transformation functions: raw JSON records in, table-shaped DataFrames out.

Nothing in here touches the database, so every function is easy to unit test
(see tests/test_transforms.py). The ETL script wires these to Postgres.
"""

from __future__ import annotations

import json
from pathlib import Path

import pandas as pd

SONG_COLUMNS = ["song_id", "title", "artist_id", "year", "duration"]
ARTIST_COLUMNS = ["artist_id", "name", "location", "latitude", "longitude"]
TIME_COLUMNS = ["start_time", "hour", "day", "week", "month", "year", "weekday"]
USER_COLUMNS = ["user_id", "first_name", "last_name", "gender", "level"]
SONGPLAY_COLUMNS = ["start_time", "user_id", "level", "song_id", "artist_id", "session_id", "location", "user_agent"]


# ------------------------------------------------------------------ reading

def find_json_files(root: Path) -> list[Path]:
    """All *.json files under root, sorted so runs are deterministic."""
    return sorted(p for p in Path(root).rglob("*.json") if p.is_file())


def read_song_files(paths: list[Path]) -> pd.DataFrame:
    """Each song file holds a single JSON object."""
    records = [json.loads(p.read_text(encoding="utf-8")) for p in paths]
    return pd.DataFrame.from_records(records)


def read_log_files(paths: list[Path]) -> pd.DataFrame:
    """Each log file is JSON Lines: one event object per line."""
    frames = [pd.read_json(p, lines=True, dtype={"userId": str}) for p in paths]
    return pd.concat(frames, ignore_index=True) if frames else pd.DataFrame()


# --------------------------------------------------------- song catalog

def songs_table(song_df: pd.DataFrame) -> pd.DataFrame:
    df = song_df[["song_id", "title", "artist_id", "year", "duration"]].copy()
    df["title"] = df["title"].str.strip()
    # The source uses year = 0 for "unknown"; NULL is the honest value.
    df["year"] = df["year"].where(df["year"] > 0).astype("Int64")
    return df.drop_duplicates("song_id")[SONG_COLUMNS]


def artists_table(song_df: pd.DataFrame) -> pd.DataFrame:
    df = song_df.rename(
        columns={
            "artist_name": "name",
            "artist_location": "location",
            "artist_latitude": "latitude",
            "artist_longitude": "longitude",
        }
    )[ARTIST_COLUMNS].copy()
    df["name"] = df["name"].str.strip()
    # empty strings are missing values in disguise
    df["location"] = df["location"].replace("", None)
    # Prefer the row with a known location when an artist appears more than once.
    df = df.sort_values("location", na_position="first")
    return df.drop_duplicates("artist_id", keep="last").sort_values("artist_id")[ARTIST_COLUMNS]


# --------------------------------------------------------- activity logs

def song_play_events(log_df: pd.DataFrame) -> pd.DataFrame:
    """Keep only song plays by logged-in users, cleaned and de-duplicated."""
    df = log_df[(log_df["page"] == "NextSong") & (log_df["userId"].fillna("").str.strip() != "")].copy()
    # The collector sometimes delivers the same event twice.
    df = df.drop_duplicates(subset=["userId", "sessionId", "itemInSession", "ts"])
    df["user_id"] = df["userId"].astype(int)
    df["start_time"] = pd.to_datetime(df["ts"], unit="ms", utc=True)
    return df.sort_values("ts").reset_index(drop=True)


def time_table(events: pd.DataFrame) -> pd.DataFrame:
    t = events["start_time"].drop_duplicates().sort_values()
    return pd.DataFrame(
        {
            "start_time": t,
            "hour": t.dt.hour,
            "day": t.dt.day,
            "week": t.dt.isocalendar().week.astype(int),
            "month": t.dt.month,
            "year": t.dt.year,
            "weekday": t.dt.weekday,
        }
    )[TIME_COLUMNS]


def users_table(events: pd.DataFrame) -> pd.DataFrame:
    """One row per user with their *latest* level (events are sorted by ts)."""
    df = events.rename(
        columns={"firstName": "first_name", "lastName": "last_name"}
    )[["user_id", "first_name", "last_name", "gender", "level"]]
    return df.drop_duplicates("user_id", keep="last").sort_values("user_id")[USER_COLUMNS]


def song_key(title: str, artist: str, duration: float) -> tuple[str, str, float]:
    """Match key for log event <-> catalog song.

    Durations are rounded because floats that travel through JSON, pandas and a
    NUMERIC column don't always compare equal bit-for-bit.
    """
    return (title.strip().lower(), artist.strip().lower(), round(float(duration), 2))


def songplays_table(events: pd.DataFrame, lookup: dict[tuple, tuple[str, str]]) -> pd.DataFrame:
    """Build fact rows. lookup maps song_key(...) -> (song_id, artist_id)."""
    ids = [
        lookup.get(song_key(s, a, d), (None, None))
        for s, a, d in zip(events["song"], events["artist"], events["length"])
    ]
    df = events.rename(columns={"sessionId": "session_id", "userAgent": "user_agent"}).copy()
    df["song_id"] = [i[0] for i in ids]
    df["artist_id"] = [i[1] for i in ids]
    return df[SONGPLAY_COLUMNS]


# ----------------------------------------------------------------- helpers

def to_rows(df: pd.DataFrame) -> list[tuple]:
    """DataFrame -> list of tuples with plain Python values (NaN/NA -> None).

    Database drivers understand None, int and float; they don't always
    understand numpy.int64 or pandas.NA.
    """
    clean = df.astype(object).where(df.notna(), None)
    return [tuple(row) for row in clean.itertuples(index=False, name=None)]
