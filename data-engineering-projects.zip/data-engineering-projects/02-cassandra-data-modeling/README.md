# 02 · Query-first modeling in Apache Cassandra

**What you'll learn:** why NoSQL modeling starts from the questions instead of the
entities, how partition keys and clustering columns work, how to keep partitions
bounded with time buckets, and how to load data fast with prepared statements and
concurrent writes.

## Relational vs. Cassandra in one paragraph

In project 01 we normalized the data once and could then ask *any* question with
joins. Cassandra has no joins and only lets you filter efficiently on the
**primary key**. In return you get linear horizontal scaling and predictable
single-digit-millisecond reads. So the workflow flips: **list the questions
first, then design one table per question**, duplicating data as needed.

## The questions and their tables

| # | Question | Table | Primary key |
|---|---|---|---|
| Q1 | Which song was playing at item *N* of session *S*? | `song_plays_by_session` | `((session_id), item_in_session)` |
| Q2 | What did user *U* play in session *S* (in order), and what's their name? | `song_plays_by_user_session` | `((user_id, session_id), item_in_session)` |
| Q3 | Which users listened to song *T*? | `users_by_song` | `((song), user_id)` |
| Q4 | What are user *U*'s most recent plays this month? | `recent_plays_by_user` | `((user_id, month), played_at DESC, session_id, item_in_session)` |

How to read a key like `((user_id, session_id), item_in_session)`:

- The inner parentheses are the **partition key**. Cassandra hashes it to decide
  which node stores the rows, and every query must supply it with `=`.
- Everything after it is a **clustering column**: rows inside a partition are
  stored sorted by it, so `ORDER BY` and range filters on it are free.
- The full key must be **unique per row**, otherwise later writes silently
  overwrite earlier ones (Cassandra `INSERT` is an upsert). That's why Q3 clusters
  on `user_id`: we *want* repeat listens to collapse into one row per listener.

Q4 shows the **time-series bucketing** pattern. Partitioning by `user_id` alone
would let one heavy listener's partition grow without limit (Cassandra prefers
partitions well under ~100 MB). Adding a `month` bucket caps the size, and
`CLUSTERING ORDER BY (played_at DESC)` makes "latest N" a cheap read with `LIMIT`.

All CQL lives in `cql.py` with comments next to each table.

## Files

| File | Purpose |
|---|---|
| `cql.py` | keyspace, `CREATE TABLE`, `INSERT` and `SELECT` for each question |
| `model.py` | pure functions: raw event → row tuple for each table |
| `etl.py` | creates the schema and loads every song play into all four tables |
| `queries.py` | answers Q1–Q4 (picks example values from the data if you pass none) |
| `tests/` | unit tests for the row builders (no Cassandra needed) |

## Run it

From the repo root:

```bash
python shared/generate_sample_data.py      # creates ./data (once)
docker compose up -d cassandra             # takes ~30-60s to become healthy
docker compose ps                          # wait for "healthy"

cd 02-cassandra-data-modeling
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt

python etl.py
python queries.py
python queries.py --song "Don't Stop the Radios"
```

You can also poke around with the CQL shell:

```bash
docker exec -it de-cassandra cqlsh -k sparkify
cqlsh:sparkify> SELECT * FROM users_by_song LIMIT 5;
```

## See the trade-off for yourself

Try a query the model wasn't designed for:

```sql
SELECT * FROM song_plays_by_session WHERE song = 'Love (Remastered)';
```

Cassandra refuses with *"Cannot execute this query as it might involve data
filtering…"*. Adding `ALLOW FILTERING` makes it run, but it scans every partition
on every node, which is fine on a laptop and a disaster in production. The right
fix is another table (that's what Q3 is).

## Things to try next

- Add a **counter** table for plays per song per day
  (`PRIMARY KEY ((day), song, artist)` with a `counter` column). Note that counters
  aren't idempotent: re-running the ETL double-counts. How would you avoid that?
- Add `default_time_to_live` to `recent_plays_by_user` so old buckets expire.
- Change the keyspace to `NetworkTopologyStrategy` and read about consistency
  levels (`ONE`, `QUORUM`, `LOCAL_QUORUM`).
