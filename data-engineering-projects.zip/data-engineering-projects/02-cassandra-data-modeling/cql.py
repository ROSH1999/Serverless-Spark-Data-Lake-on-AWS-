"""CQL for the query-first Cassandra model.

In a relational database you model the *data* and then write any query you
like. In Cassandra you model the *queries*: every question gets a table whose
PRIMARY KEY makes that question a single-partition read. Data is duplicated
across tables on purpose.

PRIMARY KEY ((partition key columns), clustering columns...)
  * partition key  -> which node(s) hold the rows; you must supply it in WHERE
  * clustering     -> sort order of rows *inside* a partition; enables ranges
"""

KEYSPACE = "sparkify"

# SimpleStrategy / RF 1 is fine on a single local node. In production you would
# use NetworkTopologyStrategy with RF 3 per data center.
CREATE_KEYSPACE = f"""
CREATE KEYSPACE IF NOT EXISTS {KEYSPACE}
WITH replication = {{'class': 'SimpleStrategy', 'replication_factor': 1}}
"""

# ---------------------------------------------------------------------------
# Q1. "Which song was playing at item <N> of session <S>?"
#     -> artist, song title, song length
#
#     WHERE session_id = ? AND item_in_session = ?
#     session_id spreads data across partitions; item_in_session makes each
#     row unique inside its session and keeps plays in order.
# ---------------------------------------------------------------------------
Q1_TABLE = "song_plays_by_session"
Q1_CREATE = f"""
CREATE TABLE IF NOT EXISTS {Q1_TABLE} (
    session_id      int,
    item_in_session int,
    artist          text,
    song            text,
    length          double,
    PRIMARY KEY ((session_id), item_in_session)
)
"""
Q1_INSERT = f"""
INSERT INTO {Q1_TABLE} (session_id, item_in_session, artist, song, length)
VALUES (?, ?, ?, ?, ?)
"""
Q1_SELECT = f"""
SELECT artist, song, length FROM {Q1_TABLE}
WHERE session_id = ? AND item_in_session = ?
"""

# ---------------------------------------------------------------------------
# Q2. "What did user <U> listen to in session <S>, in order, and who are they?"
#     -> artist, song (sorted by item_in_session), user first + last name
#
#     Composite partition key (user_id, session_id): a session belongs to one
#     user, so together they identify exactly one partition. Rows inside are
#     clustered by item_in_session, so they come back already sorted.
# ---------------------------------------------------------------------------
Q2_TABLE = "song_plays_by_user_session"
Q2_CREATE = f"""
CREATE TABLE IF NOT EXISTS {Q2_TABLE} (
    user_id         int,
    session_id      int,
    item_in_session int,
    artist          text,
    song            text,
    first_name      text,
    last_name       text,
    PRIMARY KEY ((user_id, session_id), item_in_session)
) WITH CLUSTERING ORDER BY (item_in_session ASC)
"""
Q2_INSERT = f"""
INSERT INTO {Q2_TABLE} (user_id, session_id, item_in_session, artist, song, first_name, last_name)
VALUES (?, ?, ?, ?, ?, ?, ?)
"""
Q2_SELECT = f"""
SELECT item_in_session, artist, song, first_name, last_name FROM {Q2_TABLE}
WHERE user_id = ? AND session_id = ?
"""

# ---------------------------------------------------------------------------
# Q3. "Which users have listened to the song <T>?"
#     -> user first + last name
#
#     Partition by song; cluster by user_id so each listener appears once no
#     matter how many times they played it (INSERT in Cassandra is an upsert).
# ---------------------------------------------------------------------------
Q3_TABLE = "users_by_song"
Q3_CREATE = f"""
CREATE TABLE IF NOT EXISTS {Q3_TABLE} (
    song        text,
    user_id     int,
    first_name  text,
    last_name   text,
    PRIMARY KEY ((song), user_id)
)
"""
Q3_INSERT = f"""
INSERT INTO {Q3_TABLE} (song, user_id, first_name, last_name)
VALUES (?, ?, ?, ?)
"""
Q3_SELECT = f"""
SELECT user_id, first_name, last_name FROM {Q3_TABLE}
WHERE song = ?
"""

# ---------------------------------------------------------------------------
# Q4. "What are the most recent songs user <U> played this month?"
#     -> played_at, artist, song (newest first), LIMIT n
#
#     Time-series pattern. Partitioning by user_id alone would let a heavy
#     listener's partition grow forever, so we add a month *bucket* to the
#     partition key. Clustering DESC on played_at puts the newest rows first,
#     so "latest N" is a cheap read with LIMIT.
# ---------------------------------------------------------------------------
Q4_TABLE = "recent_plays_by_user"
Q4_CREATE = f"""
CREATE TABLE IF NOT EXISTS {Q4_TABLE} (
    user_id         int,
    month           text,          -- bucket, e.g. '2026-09'
    played_at       timestamp,
    session_id      int,
    item_in_session int,
    artist          text,
    song            text,
    level           text,
    PRIMARY KEY ((user_id, month), played_at, session_id, item_in_session)
) WITH CLUSTERING ORDER BY (played_at DESC, session_id ASC, item_in_session ASC)
"""
Q4_INSERT = f"""
INSERT INTO {Q4_TABLE} (user_id, month, played_at, session_id, item_in_session, artist, song, level)
VALUES (?, ?, ?, ?, ?, ?, ?, ?)
"""
Q4_SELECT = f"""
SELECT played_at, artist, song, level FROM {Q4_TABLE}
WHERE user_id = ? AND month = ?
LIMIT ?
"""

TABLES = {
    Q1_TABLE: (Q1_CREATE, Q1_INSERT),
    Q2_TABLE: (Q2_CREATE, Q2_INSERT),
    Q3_TABLE: (Q3_CREATE, Q3_INSERT),
    Q4_TABLE: (Q4_CREATE, Q4_INSERT),
}
