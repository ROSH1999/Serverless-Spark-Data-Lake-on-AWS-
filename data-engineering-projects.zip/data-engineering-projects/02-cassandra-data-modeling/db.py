"""Shared Cassandra connection helper (settings from env, defaults match docker-compose)."""

import os

from cassandra.cluster import Cluster, Session

from cql import KEYSPACE


def connect(keyspace: str | None = KEYSPACE) -> tuple[Cluster, Session]:
    hosts = os.getenv("CASSANDRA_HOSTS", "127.0.0.1").split(",")
    port = int(os.getenv("CASSANDRA_PORT", "9042"))
    cluster = Cluster(hosts, port=port)
    session = cluster.connect(keyspace) if keyspace else cluster.connect()
    return cluster, session
