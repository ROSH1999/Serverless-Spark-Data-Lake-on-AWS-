"""Create the keyspace + query tables and load the activity logs into them.

    python etl.py               # safe to re-run: Cassandra INSERTs are upserts
    python etl.py --drop        # drop and recreate the tables first

Each event is written to *every* table that needs it. That duplication is the
normal cost of fast, predictable reads in Cassandra.
"""

from __future__ import annotations

import argparse
import os
import time
from pathlib import Path

from cassandra.concurrent import execute_concurrent_with_args

import cql
import model
from db import connect

DEFAULT_DATA_DIR = Path(os.getenv("DATA_DIR", Path(__file__).resolve().parents[1] / "data"))


def create_schema(session, drop: bool) -> None:
    session.execute(cql.CREATE_KEYSPACE)
    session.set_keyspace(cql.KEYSPACE)
    for table, (create, _) in cql.TABLES.items():
        if drop:
            session.execute(f"DROP TABLE IF EXISTS {table}")
        session.execute(create)
    print(f"Keyspace '{cql.KEYSPACE}' ready with tables: {', '.join(cql.TABLES)}")


def load(session, events: list[dict]) -> None:
    for table, (_, insert) in cql.TABLES.items():
        # Prepared statements are parsed once by the server and reused,
        # which is both faster and safe from CQL injection.
        stmt = session.prepare(insert)
        rows = [model.ROW_BUILDERS[table](e) for e in events]
        start = time.perf_counter()
        # Send many writes in flight at once instead of one round trip per row.
        results = execute_concurrent_with_args(session, stmt, rows, concurrency=64, raise_on_first_error=True)
        print(f"  {table:<28} {len(results):>6} writes  ({time.perf_counter() - start:.2f}s)")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data-dir", type=Path, default=DEFAULT_DATA_DIR)
    parser.add_argument("--drop", action="store_true", help="drop tables before loading")
    args = parser.parse_args()

    events = list(model.song_plays(model.read_events(args.data_dir / "log_data")))
    if not events:
        raise SystemExit(f"No song plays found under {args.data_dir}/log_data. Run shared/generate_sample_data.py")
    print(f"Read {len(events)} song plays")

    cluster, session = connect(keyspace=None)
    try:
        create_schema(session, args.drop)
        load(session, events)
    finally:
        cluster.shutdown()
    print("Done. Try: python queries.py")


if __name__ == "__main__":
    main()
