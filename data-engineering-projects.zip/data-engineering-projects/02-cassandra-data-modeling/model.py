"""Turn raw activity-log events into rows for each query table.

These functions are pure (no Cassandra connection), so they're unit tested in
tests/test_model.py. Each one returns exactly the tuple order its INSERT expects.
"""

from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Iterable, Iterator


def read_events(log_dir: Path) -> Iterator[dict]:
    """Stream events from every JSON-Lines file under log_dir."""
    for path in sorted(Path(log_dir).rglob("*.json")):
        with path.open(encoding="utf-8") as fh:
            for line in fh:
                if line.strip():
                    yield json.loads(line)


def song_plays(events: Iterable[dict]) -> Iterator[dict]:
    """Only song plays by logged-in users carry the fields our questions need."""
    for e in events:
        if e.get("page") == "NextSong" and e.get("userId") and e.get("song"):
            yield e


def q1_row(e: dict) -> tuple:
    return (int(e["sessionId"]), int(e["itemInSession"]), e["artist"], e["song"], float(e["length"]))


def q2_row(e: dict) -> tuple:
    return (int(e["userId"]), int(e["sessionId"]), int(e["itemInSession"]),
            e["artist"], e["song"], e["firstName"], e["lastName"])


def q3_row(e: dict) -> tuple:
    return (e["song"], int(e["userId"]), e["firstName"], e["lastName"])


def played_at(e: dict) -> datetime:
    return datetime.fromtimestamp(e["ts"] / 1000, tz=timezone.utc)


def q4_row(e: dict) -> tuple:
    ts = played_at(e)
    return (int(e["userId"]), ts.strftime("%Y-%m"), ts, int(e["sessionId"]),
            int(e["itemInSession"]), e["artist"], e["song"], e["level"])


ROW_BUILDERS = {
    "song_plays_by_session": q1_row,
    "song_plays_by_user_session": q2_row,
    "users_by_song": q3_row,
    "recent_plays_by_user": q4_row,
}
