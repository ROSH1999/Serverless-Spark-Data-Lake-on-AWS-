"""Answer the four questions the tables were designed for.

    python queries.py                         # uses example values found in the data
    python queries.py --session 12 --item 3
    python queries.py --user 10 --session 12
    python queries.py --song "Don't Stop the Radios"
    python queries.py --user 10 --month 2026-09 --limit 5

Every query hits exactly one partition, which is why each is fast no matter how
big the cluster gets.
"""

from __future__ import annotations

import argparse
import os
from pathlib import Path

import cql
import model
from db import connect

DEFAULT_DATA_DIR = Path(os.getenv("DATA_DIR", Path(__file__).resolve().parents[1] / "data"))


def example_values(data_dir: Path) -> dict:
    """Pick values that are guaranteed to exist, so the demo always returns rows."""
    plays = list(model.song_plays(model.read_events(data_dir / "log_data")))
    e = plays[len(plays) // 2]
    return {"session": int(e["sessionId"]), "item": int(e["itemInSession"]), "user": int(e["userId"]),
            "song": e["song"], "month": model.played_at(e).strftime("%Y-%m")}


def show(title: str, rows) -> None:
    print(f"\n{title}")
    rows = list(rows)
    if not rows:
        print("  (no rows)")
    for r in rows:
        print("  " + " | ".join(str(v) for v in r))


def main() -> None:
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--session", type=int)
    p.add_argument("--item", type=int)
    p.add_argument("--user", type=int)
    p.add_argument("--song")
    p.add_argument("--month", help="YYYY-MM bucket for Q4")
    p.add_argument("--limit", type=int, default=5)
    p.add_argument("--data-dir", type=Path, default=DEFAULT_DATA_DIR)
    args = p.parse_args()

    ex = example_values(args.data_dir)
    session_id = args.session if args.session is not None else ex["session"]
    item = args.item if args.item is not None else ex["item"]
    user = args.user if args.user is not None else ex["user"]
    song = args.song or ex["song"]
    month = args.month or ex["month"]

    cluster, session = connect()
    try:
        q1 = session.prepare(cql.Q1_SELECT)
        show(f"Q1  song at session_id={session_id}, item_in_session={item}  (artist | song | length)",
             session.execute(q1, (session_id, item)))

        # Q2 needs a session that belongs to this user. If the user didn't pick
        # both, use the example pair (which is consistent).
        q2_user, q2_session = (user, session_id) if args.user and args.session else (ex["user"], ex["session"])
        q2 = session.prepare(cql.Q2_SELECT)
        show(f"Q2  plays by user_id={q2_user} in session_id={q2_session}  (item | artist | song | first | last)",
             session.execute(q2, (q2_user, q2_session)))

        q3 = session.prepare(cql.Q3_SELECT)
        show(f"Q3  users who listened to '{song}'  (user_id | first | last)",
             session.execute(q3, (song,)))

        q4 = session.prepare(cql.Q4_SELECT)
        show(f"Q4  latest {args.limit} plays for user_id={user} in {month}  (played_at | artist | song | level)",
             session.execute(q4, (user, month, args.limit)))
    finally:
        cluster.shutdown()


if __name__ == "__main__":
    main()
