"""Unit tests for the row builders. No Cassandra node needed.

    pytest 02-cassandra-data-modeling
"""

import sys
from datetime import datetime, timezone
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import cql  # noqa: E402
import model  # noqa: E402

EVENT = {
    "artist": "Quiet Rivers", "auth": "Logged In", "firstName": "Zoé", "lastName": "O'Brien",
    "itemInSession": 4, "length": 201.5, "level": "paid", "page": "NextSong",
    "sessionId": 99, "song": "Señorita Love", "ts": 1_788_393_600_000, "userId": "17",
}


def test_song_plays_filters_non_plays_and_logged_out():
    events = [EVENT, {**EVENT, "page": "Home", "song": None}, {**EVENT, "userId": ""}]
    assert list(model.song_plays(events)) == [EVENT]


def test_row_shapes_match_insert_placeholders():
    for table, (_, insert) in cql.TABLES.items():
        row = model.ROW_BUILDERS[table](EVENT)
        assert len(row) == insert.count("?"), table


def test_q2_row_types():
    assert model.q2_row(EVENT) == (17, 99, 4, "Quiet Rivers", "Señorita Love", "Zoé", "O'Brien")


def test_q4_uses_month_bucket_and_utc_timestamp():
    row = model.q4_row(EVENT)
    assert row[1] == "2026-09"
    assert row[2] == datetime(2026, 9, 3, 0, 0, tzinfo=timezone.utc)


def test_read_events_streams_jsonl(tmp_path):
    day = tmp_path / "2026" / "09"
    day.mkdir(parents=True)
    (day / "2026-09-03-events.json").write_text('{"a": 1}\n\n{"a": 2}\n')
    assert [e["a"] for e in model.read_events(tmp_path)] == [1, 2]
