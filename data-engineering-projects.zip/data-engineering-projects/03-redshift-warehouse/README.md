# 03 · Cloud data warehouse on AWS Redshift (S3 → staging → star schema)

**What you'll learn:** provisioning a warehouse with Terraform, bulk-loading JSON
from S3 with `COPY`, the ELT pattern (transform with SQL *inside* the warehouse),
distribution and sort keys, idempotent loads without enforced primary keys, and
cost guard-rails.

## Architecture

```
 data/ (local JSON)
      │  upload_to_s3.py
      ▼
 s3://<raw-bucket>/raw/song_data/…        IAM role (S3 read-only)
 s3://<raw-bucket>/raw/log_data/…  ◄────────── assumed by Redshift
      │
      │  COPY … FORMAT AS JSON   (parallel, all slices at once)
      ▼
 ┌──────────────── Redshift Serverless ────────────────┐
 │  staging_events   staging_songs     (raw, 1:1 JSON) │
 │         │  INSERT … SELECT (dedupe, clean, join)    │
 │         ▼                                           │
 │  songplays (fact) ── users · songs · artists · time │
 └─────────────────────────────────────────────────────┘
```

Same data and the same star schema as project 01, so you can compare the
"Python does the work" approach (01) with "the warehouse does the work" (03).

## Key ideas in the code

- **`COPY` instead of `INSERT`.** Redshift splits the S3 files across compute
  slices and loads them in parallel. `FORMAT AS JSON 'auto ignorecase'` maps
  camelCase JSON keys (`userId`, `sessionId`) onto lowercase columns, so no
  JSONPaths file is needed.
- **`IAM_ROLE`, not access keys.** Redshift assumes a role that can only read the
  raw bucket. No credentials ever appear in SQL or config files.
- **Keys aren't enforced.** Redshift accepts `PRIMARY KEY` but doesn't check it.
  Every transform in `sql_queries.py` therefore dedupes the source with
  `ROW_NUMBER()` and anti-joins the target (`LEFT JOIN … WHERE target.id IS NULL`),
  so re-running `etl.py` never creates duplicates.
- **Upserting users** uses the classic `DELETE` + `INSERT` in one transaction to
  pick up free → paid upgrades.
- **Distribution.** `songplays` and `users` share `DISTKEY(user_id)` so their join
  is local to each slice; small dimensions use `DISTSTYLE ALL` (a copy on every
  slice); `SORTKEY(start_time)` lets date filters skip blocks.

## Files

| Path | Purpose |
|---|---|
| `infra/` | Terraform: S3 bucket, IAM role, security group, Redshift Serverless namespace + workgroup, usage limit |
| `config.py` | builds `dwh.cfg` from Terraform outputs; loads settings |
| `upload_to_s3.py` | copies `../data` to `s3://<bucket>/raw/` |
| `sql_queries.py` | DDL, COPY and transform SQL (heavily commented) |
| `create_tables.py` | drops/creates staging + star tables |
| `etl.py` | COPY → transform → row counts + quality checks |
| `analytics.sql` | example questions, plus a look at distribution skew and load history |

## Run it

You need an AWS account, credentials configured (`aws configure` or `AWS_PROFILE`),
[Terraform ≥ 1.11](https://developer.hashicorp.com/terraform/install), and
Python 3.11+.

```bash
# 0. data (from the repo root, once)
python shared/generate_sample_data.py

cd 03-redshift-warehouse
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt

# 1. infrastructure (~5-10 minutes)
cd infra
cp terraform.tfvars.example terraform.tfvars        # set allowed_cidr to your IP/32
export TF_VAR_admin_password='Choose-A-Str0ng-One'  # never written to state
terraform init
terraform apply
cd ..

# 2. config + data
python config.py --from-terraform                   # writes dwh.cfg
export REDSHIFT_PASSWORD="$TF_VAR_admin_password"
python upload_to_s3.py

# 3. load
python create_tables.py
python etl.py
```

Expected tail of `etl.py` with the default sample data:

```
Row counts:
  staging_events       5117
  staging_songs         400
  songplays            3802
  users                  50
  songs                 400
  artists                60
  time                 3789
Data quality checks:
  [PASS] staging_events loaded (value=5117)
  ...
```

Then open **Redshift query editor v2** in the AWS console (or any Postgres client
with `sslmode=require`) and run `analytics.sql`.

## Cost and clean-up

Redshift Serverless charges per RPU-hour while queries run, with a 60-second
minimum per query, plus a small amount for storage. This project uses the smallest
base capacity (8 RPUs) and a **usage limit that deactivates the workgroup** after
16 RPU-hours in a day. Check the
[current pricing](https://aws.amazon.com/redshift/pricing/) for your region, and
new accounts may be eligible for a Redshift Serverless free trial credit.

When you're done:

```bash
cd infra && terraform destroy
```

## Troubleshooting

- **COPY failed** → `SELECT * FROM sys_load_error_detail ORDER BY start_time DESC LIMIT 10;`
  shows the file, line and reason.
- **Can't connect / timeout** → your IP changed. Update `allowed_cidr` and `terraform apply`.
- **"Not enough subnets/AZs"** on apply → Redshift Serverless needs subnets in at
  least three Availability Zones. Pick a region where the default VPC has ≥ 3.
- **Password rejected** → Redshift requires 8–64 chars with upper, lower and a digit.

## Things to try next

- Rewrite the users upsert with `MERGE`.
- Partition the raw data by date (`raw/log_data/2026/09/03/`) and COPY one day at a
  time — that's what the Airflow version in project 05 does.
- Load the Parquet output of project 04 with `COPY … FORMAT AS PARQUET`, or query it
  in place with Redshift Spectrum.
