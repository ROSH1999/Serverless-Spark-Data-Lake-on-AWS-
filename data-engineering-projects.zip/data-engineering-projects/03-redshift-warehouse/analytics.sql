-- Example analytics on the Redshift star schema. Paste into the Redshift query
-- editor v2 or run with any Postgres-compatible client (psql works too):
--   psql "host=<endpoint> port=5439 dbname=sparkify user=awsuser sslmode=require" -f analytics.sql

-- 1. Top artists by unique listeners
SELECT a.name, COUNT(DISTINCT sp.user_id) AS listeners, COUNT(*) AS plays
FROM songplays sp
JOIN artists a ON a.artist_id = sp.artist_id
GROUP BY a.name
ORDER BY listeners DESC, plays DESC
LIMIT 10;

-- 2. Daily active users and plays, split by subscription level
SELECT TRUNC(sp.start_time) AS day, sp.level,
       COUNT(DISTINCT sp.user_id) AS active_users,
       COUNT(*) AS plays
FROM songplays sp
GROUP BY 1, 2
ORDER BY 1, 2;

-- 3. Weekday vs weekend listening (weekday: 0 = Monday ... 6 = Sunday)
SELECT CASE WHEN t.weekday >= 5 THEN 'weekend' ELSE 'weekday' END AS part_of_week,
       COUNT(*) AS plays
FROM songplays sp
JOIN time t ON t.start_time = sp.start_time
GROUP BY 1;

-- 4. How are the tables distributed and sorted? skew_rows near 1.0 = even spread.
SELECT "table", diststyle, sortkey1, tbl_rows, skew_rows
FROM svv_table_info
WHERE "table" IN ('songplays', 'users', 'songs', 'artists', 'time')
ORDER BY "table";

-- 5. What did the last COPY commands do? (useful when a load looks wrong)
SELECT query_id, table_name, data_source, loaded_rows, duration / 1000000.0 AS seconds
FROM sys_load_history
ORDER BY start_time DESC
LIMIT 5;
