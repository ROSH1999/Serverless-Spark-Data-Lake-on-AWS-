"""Read warehouse settings from dwh.cfg (and environment), or generate dwh.cfg
from the Terraform outputs in ./infra.

    python config.py --from-terraform     # writes dwh.cfg after `terraform apply`
    python config.py                      # prints the active settings (password hidden)

The admin password is never written to disk: set REDSHIFT_PASSWORD in your
shell (it's the same value you gave Terraform as TF_VAR_admin_password).
"""

from __future__ import annotations

import argparse
import configparser
import json
import os
import subprocess
from dataclasses import dataclass
from pathlib import Path

HERE = Path(__file__).resolve().parent
CFG_PATH = HERE / "dwh.cfg"


@dataclass
class Settings:
    host: str
    port: int
    database: str
    user: str
    password: str
    role_arn: str
    bucket: str
    region: str

    @property
    def log_data(self) -> str:
        return f"s3://{self.bucket}/raw/log_data/"

    @property
    def song_data(self) -> str:
        return f"s3://{self.bucket}/raw/song_data/"


def load() -> Settings:
    cfg = configparser.ConfigParser()
    if not cfg.read(CFG_PATH):
        raise SystemExit(f"{CFG_PATH.name} not found. Run `python config.py --from-terraform` "
                         f"or copy dwh.cfg.example to dwh.cfg and fill it in.")
    password = os.getenv("REDSHIFT_PASSWORD") or cfg.get("redshift", "password", fallback="")
    if not password:
        raise SystemExit("Set REDSHIFT_PASSWORD (the admin password you gave Terraform).")
    return Settings(
        host=cfg["redshift"]["host"],
        port=cfg.getint("redshift", "port", fallback=5439),
        database=cfg["redshift"]["database"],
        user=cfg["redshift"]["user"],
        password=password,
        role_arn=cfg["iam"]["role_arn"],
        bucket=cfg["s3"]["bucket"],
        region=cfg["s3"]["region"],
    )


def write_from_terraform() -> None:
    out = subprocess.run(
        ["terraform", f"-chdir={HERE / 'infra'}", "output", "-json"],
        check=True, capture_output=True, text=True,
    )
    tf = {k: v["value"] for k, v in json.loads(out.stdout).items()}
    cfg = configparser.ConfigParser()
    cfg["redshift"] = {"host": tf["redshift_host"], "port": str(tf["redshift_port"]),
                       "database": tf["redshift_database"], "user": tf["redshift_admin_username"]}
    cfg["iam"] = {"role_arn": tf["redshift_s3_role_arn"]}
    cfg["s3"] = {"bucket": tf["raw_bucket"], "region": tf["region"]}
    with CFG_PATH.open("w") as fh:
        cfg.write(fh)
    print(f"Wrote {CFG_PATH.name}. Now: export REDSHIFT_PASSWORD='<your admin password>'")


if __name__ == "__main__":
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--from-terraform", action="store_true")
    args = p.parse_args()
    if args.from_terraform:
        write_from_terraform()
    else:
        s = load()
        print({**s.__dict__, "password": "****"})
