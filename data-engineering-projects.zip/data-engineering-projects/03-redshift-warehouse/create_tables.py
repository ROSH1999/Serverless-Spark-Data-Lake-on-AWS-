"""(Re)create staging and star-schema tables in Redshift. Drops existing tables.

    python create_tables.py
"""

import redshift_connector

import config
from sql_queries import CREATE_TABLES, DROP_TABLES


def main() -> None:
    s = config.load()
    with redshift_connector.connect(host=s.host, port=s.port, database=s.database,
                                    user=s.user, password=s.password) as conn:
        with conn.cursor() as cur:
            for stmt in DROP_TABLES + CREATE_TABLES:
                cur.execute(stmt)
        conn.commit()
    print("Created staging_events, staging_songs, songplays, users, songs, artists, time")


if __name__ == "__main__":
    main()
