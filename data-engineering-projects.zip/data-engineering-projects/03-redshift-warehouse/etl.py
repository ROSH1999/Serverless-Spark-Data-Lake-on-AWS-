"""Load S3 -> Redshift staging -> star schema, then run data quality checks.

    python etl.py

Steps
-----
1. TRUNCATE + COPY the raw JSON from S3 into staging_events / staging_songs
2. Transform with INSERT ... SELECT inside Redshift (ELT), one transaction
3. Run data quality checks and print row counts
"""

from __future__ import annotations

import time

import redshift_connector

import config
import sql_queries as q


def timed(cur, label: str, sql: str) -> None:
    start = time.perf_counter()
    cur.execute(sql)
    print(f"  {label:<24} {time.perf_counter() - start:6.1f}s")


def stage(conn, s: config.Settings) -> None:
    print(f"Staging from s3://{s.bucket}/raw/ ...")
    with conn.cursor() as cur:
        for stmt in q.TRUNCATE_STAGING:
            cur.execute(stmt)
        try:
            timed(cur, "COPY staging_songs", q.COPY_STAGING_SONGS.format(song_data=s.song_data,
                                                                           role_arn=s.role_arn, region=s.region))
            timed(cur, "COPY staging_events", q.COPY_STAGING_EVENTS.format(log_data=s.log_data,
                                                                             role_arn=s.role_arn, region=s.region))
        except redshift_connector.error.ProgrammingError:
            conn.rollback()
            print("COPY failed. The details are in the load error log; run in the query editor:\n"
                  "  SELECT * FROM sys_load_error_detail ORDER BY start_time DESC LIMIT 10;")
            raise
    conn.commit()


def transform(conn) -> None:
    print("Transforming staging -> star schema ...")
    # All inserts in one transaction: readers never see a half-loaded warehouse.
    with conn.cursor() as cur:
        for label, sql in q.TRANSFORMS:
            timed(cur, label, sql)
    conn.commit()


def check(conn) -> None:
    print("Row counts:")
    with conn.cursor() as cur:
        for table in ["staging_events", "staging_songs", "songplays", "users", "songs", "artists", "time"]:
            cur.execute(q.ROW_COUNTS.format(table))
            name, count = cur.fetchone()
            print(f"  {name:<16} {count:>8}")

        print("Data quality checks:")
        failed = []
        for name, sql, ok in q.QUALITY_CHECKS:
            cur.execute(sql)
            value = cur.fetchone()[0]
            passed = ok(value)
            print(f"  [{'PASS' if passed else 'FAIL'}] {name} (value={value})")
            if not passed:
                failed.append(name)
    if failed:
        raise SystemExit(f"Data quality checks failed: {failed}")


def main() -> None:
    s = config.load()
    with redshift_connector.connect(host=s.host, port=s.port, database=s.database,
                                    user=s.user, password=s.password) as conn:
        stage(conn, s)
        transform(conn)
        check(conn)
    print("Done.")


if __name__ == "__main__":
    main()
