# Infrastructure for the Redshift warehouse project:
#
#   S3 bucket (raw JSON)  ──COPY──►  Redshift Serverless (namespace + workgroup)
#                                     │ assumes
#                                     ▼
#                         IAM role with read-only access to the bucket
#
# Redshift Serverless bills per RPU-hour only while queries run (plus storage),
# which suits a learning project far better than an always-on provisioned cluster.

data "aws_vpc" "default" {
  default = true
}

data "aws_subnets" "default" {
  filter {
    name   = "vpc-id"
    values = [data.aws_vpc.default.id]
  }
}

# ------------------------------------------------------------------ S3 (raw)

resource "aws_s3_bucket" "raw" {
  bucket_prefix = "${var.project}-raw-"
  force_destroy = true # lets `terraform destroy` remove the sample data too
}

resource "aws_s3_bucket_public_access_block" "raw" {
  bucket                  = aws_s3_bucket.raw.id
  block_public_acls       = true
  block_public_policy     = true
  ignore_public_acls      = true
  restrict_public_buckets = true
}

resource "aws_s3_bucket_server_side_encryption_configuration" "raw" {
  bucket = aws_s3_bucket.raw.id
  rule {
    apply_server_side_encryption_by_default {
      sse_algorithm = "AES256"
    }
  }
}

# --------------------------------------------- IAM role Redshift assumes for COPY

data "aws_iam_policy_document" "redshift_assume" {
  statement {
    actions = ["sts:AssumeRole"]
    principals {
      type        = "Service"
      identifiers = ["redshift.amazonaws.com", "redshift-serverless.amazonaws.com"]
    }
  }
}

data "aws_iam_policy_document" "read_raw_bucket" {
  statement {
    sid       = "ListBucket"
    actions   = ["s3:ListBucket", "s3:GetBucketLocation"]
    resources = [aws_s3_bucket.raw.arn]
  }
  statement {
    sid       = "ReadObjects"
    actions   = ["s3:GetObject"]
    resources = ["${aws_s3_bucket.raw.arn}/*"]
  }
}

resource "aws_iam_role" "redshift_s3_read" {
  name_prefix        = "${var.project}-s3-read-"
  assume_role_policy = data.aws_iam_policy_document.redshift_assume.json
}

resource "aws_iam_role_policy" "read_raw_bucket" {
  name   = "read-raw-bucket"
  role   = aws_iam_role.redshift_s3_read.id
  policy = data.aws_iam_policy_document.read_raw_bucket.json
}

# ---------------------------------------------------------- network access

resource "aws_security_group" "redshift" {
  name_prefix = "${var.project}-"
  description = "Redshift Serverless access for ${var.project}"
  vpc_id      = data.aws_vpc.default.id
}

resource "aws_vpc_security_group_ingress_rule" "redshift_from_me" {
  security_group_id = aws_security_group.redshift.id
  description       = "Redshift from allowed CIDR"
  cidr_ipv4         = var.allowed_cidr
  ip_protocol       = "tcp"
  from_port         = 5439
  to_port           = 5439
}

resource "aws_vpc_security_group_egress_rule" "all_out" {
  security_group_id = aws_security_group.redshift.id
  cidr_ipv4         = "0.0.0.0/0"
  ip_protocol       = "-1"
}

# ------------------------------------------------------- Redshift Serverless

# The namespace holds storage: databases, users, schemas, and attached IAM roles.
resource "aws_redshiftserverless_namespace" "this" {
  namespace_name = var.project
  db_name        = var.db_name
  admin_username = var.admin_username

  # Write-only: sent to AWS but never saved in the Terraform state file.
  admin_user_password_wo         = var.admin_password
  admin_user_password_wo_version = var.admin_password_version

  iam_roles            = [aws_iam_role.redshift_s3_read.arn]
  default_iam_role_arn = aws_iam_role.redshift_s3_read.arn
}

# The workgroup holds compute: RPUs, network placement and the endpoint.
resource "aws_redshiftserverless_workgroup" "this" {
  namespace_name = aws_redshiftserverless_namespace.this.namespace_name
  workgroup_name = var.project
  base_capacity  = var.base_capacity
  max_capacity   = var.max_capacity

  # Public so you can connect from your laptop; the security group limits who.
  # Requires subnets in at least three Availability Zones (true for the default
  # VPC in most regions).
  publicly_accessible = true
  subnet_ids          = data.aws_subnets.default.ids
  security_group_ids  = [aws_security_group.redshift.id]
}

# Cost guard-rail: deactivate the workgroup if it burns through the daily budget.
resource "aws_redshiftserverless_usage_limit" "daily" {
  resource_arn  = aws_redshiftserverless_workgroup.this.arn
  usage_type    = "serverless-compute"
  amount        = var.daily_rpu_hours_limit
  period        = "daily"
  breach_action = "deactivate"
}
