# These names are read by ../config.py --from-terraform to build dwh.cfg.

output "region" {
  value = var.region
}

output "raw_bucket" {
  description = "Upload raw JSON here (upload_to_s3.py)."
  value       = aws_s3_bucket.raw.bucket
}

output "redshift_host" {
  value = aws_redshiftserverless_workgroup.this.endpoint[0].address
}

output "redshift_port" {
  value = aws_redshiftserverless_workgroup.this.endpoint[0].port
}

output "redshift_database" {
  value = aws_redshiftserverless_namespace.this.db_name
}

output "redshift_admin_username" {
  value = aws_redshiftserverless_namespace.this.admin_username
}

output "redshift_s3_role_arn" {
  description = "Role used by COPY ... IAM_ROLE."
  value       = aws_iam_role.redshift_s3_read.arn
}
