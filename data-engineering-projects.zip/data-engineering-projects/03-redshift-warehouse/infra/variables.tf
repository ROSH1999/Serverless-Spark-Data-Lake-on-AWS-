variable "region" {
  description = "AWS region for every resource."
  type        = string
  default     = "us-east-1"
}

variable "project" {
  description = "Name used for the Redshift namespace/workgroup and as a prefix elsewhere. Lowercase letters, digits and hyphens."
  type        = string
  default     = "sparkify-dwh"

  validation {
    condition     = can(regex("^[a-z][a-z0-9-]{2,30}$", var.project))
    error_message = "Use 3-31 lowercase letters, digits or hyphens, starting with a letter."
  }
}

variable "db_name" {
  description = "Name of the first database created in the namespace."
  type        = string
  default     = "sparkify"
}

variable "admin_username" {
  description = "Redshift admin user."
  type        = string
  default     = "awsuser"
}

variable "admin_password" {
  description = "Redshift admin password. Pass it with TF_VAR_admin_password; it is ephemeral and never stored in state."
  type        = string
  sensitive   = true
  ephemeral   = true

  validation {
    condition = (
      length(var.admin_password) >= 8 && length(var.admin_password) <= 64 &&
      can(regex("[A-Z]", var.admin_password)) && can(regex("[a-z]", var.admin_password)) &&
      can(regex("[0-9]", var.admin_password))
    )
    error_message = "8-64 characters with at least one uppercase letter, one lowercase letter and one digit."
  }
}

variable "admin_password_version" {
  description = "Bump this number to push a new admin_password to Redshift."
  type        = number
  default     = 1
}

variable "allowed_cidr" {
  description = "CIDR allowed to connect on port 5439, e.g. your public IP as 203.0.113.10/32 (curl -s https://checkip.amazonaws.com)."
  type        = string

  validation {
    condition     = can(cidrhost(var.allowed_cidr, 0)) && var.allowed_cidr != "0.0.0.0/0"
    error_message = "Provide a valid CIDR, and please don't open the warehouse to the whole internet."
  }
}

variable "base_capacity" {
  description = "Base Redshift Processing Units (RPUs). 8 is the smallest and cheapest setting."
  type        = number
  default     = 8
}

variable "max_capacity" {
  description = "Upper bound on RPUs the workgroup may scale to."
  type        = number
  default     = 32
}

variable "daily_rpu_hours_limit" {
  description = "Cost guard-rail: RPU-hours per day after which the workgroup is deactivated."
  type        = number
  default     = 16
}
