"""SQL for the Redshift warehouse: staging tables, COPY, and the star schema.

Flow:   S3 (raw JSON) --COPY--> staging_* tables --INSERT...SELECT--> star schema

Why stage first? COPY is Redshift's bulk loader: it reads many S3 files in
parallel across the cluster's slices and is orders of magnitude faster than
row-by-row INSERTs. Staging tables mirror the raw JSON 1:1, then plain SQL does
the cleaning and reshaping inside the warehouse ("ELT").

Table distribution (how rows are spread across compute slices):
  * songplays, users: DISTKEY(user_id) -> plays and their user live on the same
    slice, so the most common join needs no data shuffling.
  * songs, artists, time: DISTSTYLE ALL -> small dimensions copied to every
    slice; joins against them never move data.
  * SORTKEY(start_time) on songplays/time -> date-range filters skip blocks.
"""

# ------------------------------------------------------------------ DROP

DROP_TABLES = [
    f"DROP TABLE IF EXISTS {t}"
    for t in ["staging_events", "staging_songs", "songplays", "users", "songs", "artists", "time"]
]

# --------------------------------------------------------------- STAGING
# Column names are lowercase versions of the JSON keys so COPY ... 'auto ignorecase'
# can map them without a JSONPaths file.

CREATE_STAGING_EVENTS = """
CREATE TABLE IF NOT EXISTS staging_events (
    artist          VARCHAR(512),
    auth            VARCHAR(32),
    firstname       VARCHAR(128),
    gender          CHAR(1),
    iteminsession   INTEGER,
    lastname        VARCHAR(128),
    length          DOUBLE PRECISION,
    level           VARCHAR(8),
    location        VARCHAR(256),
    method          VARCHAR(8),
    page            VARCHAR(32),
    registration    DOUBLE PRECISION,
    sessionid       INTEGER,
    song            VARCHAR(512),
    status          INTEGER,
    ts              BIGINT,
    useragent       VARCHAR(512),
    userid          VARCHAR(16)
)
"""

CREATE_STAGING_SONGS = """
CREATE TABLE IF NOT EXISTS staging_songs (
    num_songs         INTEGER,
    artist_id         VARCHAR(32),
    artist_latitude   DOUBLE PRECISION,
    artist_longitude  DOUBLE PRECISION,
    artist_location   VARCHAR(512),
    artist_name       VARCHAR(512),
    song_id           VARCHAR(32),
    title             VARCHAR(512),
    duration          DOUBLE PRECISION,
    year              INTEGER
)
"""

# ------------------------------------------------------------ STAR SCHEMA
# Redshift accepts PRIMARY KEY / REFERENCES but does NOT enforce them. They are
# hints for the query planner, so the load SQL below must avoid duplicates itself.

CREATE_SONGPLAYS = """
CREATE TABLE IF NOT EXISTS songplays (
    songplay_id  BIGINT IDENTITY(0, 1) PRIMARY KEY,
    start_time   TIMESTAMP NOT NULL REFERENCES time (start_time),
    user_id      INTEGER NOT NULL REFERENCES users (user_id),
    level        VARCHAR(8) NOT NULL,
    song_id      VARCHAR(32) REFERENCES songs (song_id),
    artist_id    VARCHAR(32) REFERENCES artists (artist_id),
    session_id   INTEGER NOT NULL,
    location     VARCHAR(256),
    user_agent   VARCHAR(512)
)
DISTKEY (user_id)
SORTKEY (start_time)
"""

CREATE_USERS = """
CREATE TABLE IF NOT EXISTS users (
    user_id     INTEGER PRIMARY KEY,
    first_name  VARCHAR(128),
    last_name   VARCHAR(128),
    gender      CHAR(1),
    level       VARCHAR(8) NOT NULL
)
DISTKEY (user_id)
SORTKEY (user_id)
"""

CREATE_SONGS = """
CREATE TABLE IF NOT EXISTS songs (
    song_id    VARCHAR(32) PRIMARY KEY,
    title      VARCHAR(512) NOT NULL,
    artist_id  VARCHAR(32) NOT NULL,
    year       SMALLINT,
    duration   DECIMAL(10, 5) NOT NULL
)
DISTSTYLE ALL
SORTKEY (song_id)
"""

CREATE_ARTISTS = """
CREATE TABLE IF NOT EXISTS artists (
    artist_id  VARCHAR(32) PRIMARY KEY,
    name       VARCHAR(512) NOT NULL,
    location   VARCHAR(512),
    latitude   DOUBLE PRECISION,
    longitude  DOUBLE PRECISION
)
DISTSTYLE ALL
SORTKEY (artist_id)
"""

CREATE_TIME = """
CREATE TABLE IF NOT EXISTS time (
    start_time  TIMESTAMP PRIMARY KEY,
    hour        SMALLINT NOT NULL,
    day         SMALLINT NOT NULL,
    week        SMALLINT NOT NULL,
    month       SMALLINT NOT NULL,
    year        SMALLINT NOT NULL,
    weekday     SMALLINT NOT NULL      -- 0 = Monday ... 6 = Sunday
)
DISTSTYLE ALL
SORTKEY (start_time)
"""

CREATE_TABLES = [
    CREATE_STAGING_EVENTS, CREATE_STAGING_SONGS,
    CREATE_USERS, CREATE_SONGS, CREATE_ARTISTS, CREATE_TIME, CREATE_SONGPLAYS,
]

# ------------------------------------------------------------------ COPY
# IAM_ROLE: Redshift assumes this role to read S3, so no access keys are ever
# stored in SQL or config. COMPUPDATE/STATUPDATE OFF skip analysis that isn't
# useful for small, frequently-truncated staging tables.

COPY_STAGING_EVENTS = """
COPY staging_events
FROM '{log_data}'
IAM_ROLE '{role_arn}'
FORMAT AS JSON 'auto ignorecase'
REGION '{region}'
TRUNCATECOLUMNS
COMPUPDATE OFF STATUPDATE OFF
"""

COPY_STAGING_SONGS = """
COPY staging_songs
FROM '{song_data}'
IAM_ROLE '{role_arn}'
FORMAT AS JSON 'auto'
REGION '{region}'
TRUNCATECOLUMNS
COMPUPDATE OFF STATUPDATE OFF
"""

TRUNCATE_STAGING = ["TRUNCATE staging_events", "TRUNCATE staging_songs"]

# -------------------------------------------------------------- TRANSFORMS
# Every statement is idempotent: re-running the ETL adds nothing new.
# Pattern: dedupe the source with ROW_NUMBER(), then LEFT JOIN the target and
# keep only rows that aren't there yet (an "anti-join").

# A reusable fragment: song plays by logged-in users, with a real timestamp.
_PLAYS = """
    SELECT DISTINCT
        TIMESTAMP 'epoch' + (ts / 1000) * INTERVAL '1 second' AS start_time,
        CAST(userid AS INTEGER)                              AS user_id,
        level, song, artist, length, sessionid, location, useragent, ts,
        firstname, lastname, gender
    FROM staging_events
    WHERE page = 'NextSong' AND NULLIF(TRIM(userid), '') IS NOT NULL
"""

INSERT_ARTISTS = """
INSERT INTO artists (artist_id, name, location, latitude, longitude)
SELECT src.artist_id, src.artist_name, NULLIF(TRIM(src.artist_location), ''),
       src.artist_latitude, src.artist_longitude
FROM (
    SELECT *,
           ROW_NUMBER() OVER (
               PARTITION BY artist_id
               -- prefer a row that actually has a location
               ORDER BY CASE WHEN NULLIF(TRIM(artist_location), '') IS NULL THEN 1 ELSE 0 END, song_id
           ) AS rn
    FROM staging_songs
) src
LEFT JOIN artists a ON a.artist_id = src.artist_id
WHERE src.rn = 1 AND a.artist_id IS NULL
"""

INSERT_SONGS = """
INSERT INTO songs (song_id, title, artist_id, year, duration)
SELECT src.song_id, TRIM(src.title), src.artist_id, NULLIF(src.year, 0), src.duration
FROM (
    SELECT *, ROW_NUMBER() OVER (PARTITION BY song_id ORDER BY title) AS rn
    FROM staging_songs
) src
LEFT JOIN songs s ON s.song_id = src.song_id
WHERE src.rn = 1 AND s.song_id IS NULL
"""

INSERT_TIME = f"""
INSERT INTO time (start_time, hour, day, week, month, year, weekday)
SELECT p.start_time,
       EXTRACT(hour  FROM p.start_time),
       EXTRACT(day   FROM p.start_time),
       EXTRACT(week  FROM p.start_time),
       EXTRACT(month FROM p.start_time),
       EXTRACT(year  FROM p.start_time),
       CAST(EXTRACT(dow FROM p.start_time) + 6 AS INTEGER) % 7   -- shift so Monday = 0
FROM (SELECT DISTINCT start_time FROM ({_PLAYS}) plays) p
LEFT JOIN time t ON t.start_time = p.start_time
WHERE t.start_time IS NULL
"""

# Upsert = DELETE the users we're about to reload, then INSERT their latest row.
# Redshift also supports MERGE; DELETE + INSERT in one transaction is the classic
# pattern and works on every version.
DELETE_CHANGED_USERS = """
DELETE FROM users
WHERE user_id IN (
    SELECT DISTINCT CAST(userid AS INTEGER) FROM staging_events
    WHERE page = 'NextSong' AND NULLIF(TRIM(userid), '') IS NOT NULL
)
"""

INSERT_USERS = f"""
INSERT INTO users (user_id, first_name, last_name, gender, level)
SELECT user_id, firstname, lastname, gender, level
FROM (
    SELECT *, ROW_NUMBER() OVER (PARTITION BY user_id ORDER BY ts DESC) AS rn
    FROM ({_PLAYS}) plays
) latest
WHERE rn = 1
"""

# Plays are matched to the catalog on title + artist name + duration (rounded,
# because floating point values rarely compare equal). Unmatched plays are kept
# with NULL song_id/artist_id.
INSERT_SONGPLAYS = f"""
INSERT INTO songplays (start_time, user_id, level, song_id, artist_id, session_id, location, user_agent)
SELECT p.start_time, p.user_id, p.level, cat.song_id, cat.artist_id, p.sessionid, p.location, p.useragent
FROM ({_PLAYS}) p
LEFT JOIN (
    SELECT s.song_id, s.artist_id,
           LOWER(s.title)                         AS title_key,
           LOWER(a.name)                          AS artist_key,
           ROUND(CAST(s.duration AS DECIMAL(12, 5)), 2) AS duration_key,
           ROW_NUMBER() OVER (
               PARTITION BY LOWER(s.title), LOWER(a.name), ROUND(CAST(s.duration AS DECIMAL(12, 5)), 2)
               ORDER BY s.song_id
           ) AS rn
    FROM songs s
    JOIN artists a ON a.artist_id = s.artist_id
) cat
    ON  cat.rn = 1
    AND cat.title_key    = LOWER(p.song)
    AND cat.artist_key   = LOWER(p.artist)
    AND cat.duration_key = ROUND(CAST(p.length AS DECIMAL(12, 5)), 2)
LEFT JOIN songplays existing
    ON  existing.user_id    = p.user_id
    AND existing.session_id = p.sessionid
    AND existing.start_time = p.start_time
WHERE existing.songplay_id IS NULL
"""

# Order matters: dimensions first, the fact table last (it joins songs/artists).
TRANSFORMS = [
    ("artists", INSERT_ARTISTS),
    ("songs", INSERT_SONGS),
    ("time", INSERT_TIME),
    ("users (delete changed)", DELETE_CHANGED_USERS),
    ("users", INSERT_USERS),
    ("songplays", INSERT_SONGPLAYS),
]

# ---------------------------------------------------------- QUALITY CHECKS

QUALITY_CHECKS = [
    ("staging_events loaded", "SELECT COUNT(*) FROM staging_events", lambda n: n > 0),
    ("staging_songs loaded", "SELECT COUNT(*) FROM staging_songs", lambda n: n > 0),
    ("songplays has rows", "SELECT COUNT(*) FROM songplays", lambda n: n > 0),
    ("no duplicate users", "SELECT COUNT(*) - COUNT(DISTINCT user_id) FROM users", lambda n: n == 0),
    ("no duplicate songs", "SELECT COUNT(*) - COUNT(DISTINCT song_id) FROM songs", lambda n: n == 0),
    ("no duplicate plays",
     "SELECT COUNT(*) FROM (SELECT user_id, session_id, start_time FROM songplays "
     "GROUP BY 1, 2, 3 HAVING COUNT(*) > 1) d",
     lambda n: n == 0),
    ("every play has a time row",
     "SELECT COUNT(*) FROM songplays sp LEFT JOIN time t ON t.start_time = sp.start_time "
     "WHERE t.start_time IS NULL",
     lambda n: n == 0),
]

ROW_COUNTS = "SELECT '{0}', COUNT(*) FROM {0}"
