"""Upload the local sample data to the raw S3 bucket created by Terraform.

    python upload_to_s3.py                    # bucket from dwh.cfg
    python upload_to_s3.py --bucket my-bucket

Files keep their folder layout under the raw/ prefix:
    data/log_data/2026/09/...  ->  s3://<bucket>/raw/log_data/2026/09/...
"""

from __future__ import annotations

import argparse
import configparser
import os
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

import boto3

HERE = Path(__file__).resolve().parent
DEFAULT_DATA_DIR = Path(os.getenv("DATA_DIR", HERE.parent / "data"))


def bucket_from_cfg() -> str:
    cfg = configparser.ConfigParser()
    cfg.read(HERE / "dwh.cfg")
    try:
        return cfg["s3"]["bucket"]
    except KeyError:
        raise SystemExit("No bucket given and none in dwh.cfg. Use --bucket or run config.py --from-terraform.") from None


def main() -> None:
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--bucket")
    p.add_argument("--prefix", default="raw")
    p.add_argument("--data-dir", type=Path, default=DEFAULT_DATA_DIR)
    args = p.parse_args()
    bucket = args.bucket or bucket_from_cfg()

    files = [f for sub in ("song_data", "log_data") for f in (args.data_dir / sub).rglob("*.json")]
    if not files:
        raise SystemExit(f"No JSON files under {args.data_dir}. Run shared/generate_sample_data.py first.")

    s3 = boto3.client("s3")  # uses your normal AWS credentials / profile

    def upload(path: Path) -> None:
        key = f"{args.prefix}/{path.relative_to(args.data_dir).as_posix()}"
        s3.upload_file(str(path), bucket, key, ExtraArgs={"ContentType": "application/json"})

    # Many small files: upload them in parallel.
    with ThreadPoolExecutor(max_workers=16) as pool:
        list(pool.map(upload, files))
    print(f"Uploaded {len(files)} files to s3://{bucket}/{args.prefix}/")


if __name__ == "__main__":
    main()
