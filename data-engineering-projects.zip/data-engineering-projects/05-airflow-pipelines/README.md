# 05 · Orchestrating ETL with Apache Airflow 3

**What you'll learn:** turning scripts into scheduled, retryable, observable
pipelines; writing custom operators; templating tasks with the run's data
interval; backfills and why idempotency matters for them; the TaskFlow API and
dynamic task mapping; keeping connections out of code; and testing DAGs.

Runs on **Airflow 3.3** (the current release line as of this writing) with the
`airflow.sdk` authoring interface.

## The DAGs

| DAG | Schedule | What it does | Needs |
|---|---|---|---|
| `sparkify_postgres_etl` | `@daily`, backfills 2026-09-01 → 09-07 | stages **one day** of logs + the song catalog into Postgres, loads the star schema, checks quality | local Postgres |
| `weather_ingest` | `@hourly` | fetches 5 cities **in parallel** (dynamic task mapping) from Open-Meteo, upserts, checks freshness | local Postgres, internet |
| `sparkify_redshift_etl` | `@daily` (paused) | `COPY`s one day from S3 into Redshift and loads the warehouse | project 03's AWS stack |

### `sparkify_postgres_etl`

```
create_tables ─┬─ stage_songs ── load_artists ── load_songs ──┐
               └─ stage_events ─┬─ load_users ────────────────┼─ load_songplays ── quality_checks
                                └─ load_time ─────────────────┘
```

- `stage_events` reads `log_data/YYYY/MM/YYYY-MM-DD-events.json` for the day
  given by the run's `data_interval_start` (a Jinja template rendered at run
  time), so the 2026-09-03 run loads exactly that file.
  This is what makes **backfills** work: unpause the DAG and Airflow creates one
  run per day since `start_date` (`catchup=True`).
- Every load is an **upsert**, so clearing a task or re-running a day is safe.
  The users upsert even guards against *out-of-order* re-runs: it only overwrites
  a row when the incoming `last_seen_at` is newer (see `plugins/sparkify/postgres_sql.py`).
- `max_active_runs=1` because runs share staging tables.
- The quality check uses the same day: "were any plays loaded for
  2026-09-03, and did at least half of them match the catalog?"

### `weather_ingest`

```
ensure_schema ─► cities ─► fetch[×5] ─► transform[×5] ─► load ─► check_freshness
```

Written with `@dag` / `@task` (TaskFlow). `fetch.expand(city=cities())` creates one
task instance **per city at runtime**, so a flaky city retries on its own with
exponential backoff while the others carry on. It imports project 06's
`weather.py` instead of copying it: the API client has no DB code, so it drops
straight into Airflow.

### `sparkify_redshift_etl`

Same shape as the Postgres DAG but with `StageToRedshiftOperator` (`COPY … IAM_ROLE`)
and the SQL imported from project 03. Bucket, role and region come from Airflow
**Variables** through templates (`{{ var.value.sparkify_raw_bucket }}`), which are
resolved at run time, not on every DAG parse.

## Custom operators (`plugins/sparkify/operators.py`)

| Operator | Job |
|---|---|
| `StageJsonToPostgresOperator` | load local JSON / JSON-Lines into a staging table (keys matched to columns case-insensitively) |
| `StageToRedshiftOperator` | `TRUNCATE` + `COPY` from S3 with an IAM role |
| `LoadTableOperator` | run `INSERT … SELECT` (optionally `TRUNCATE` first) in one transaction, log the row count |
| `DataQualityOperator` | run SQL checks like `{"sql": …, "op": "gt", "value": 0}` and fail with a clear message |

They work with **any** SQL connection: they ask the connection for its hook, so
the same `LoadTableOperator` drives Postgres and Redshift.

## Run it

Prerequisites: Docker with Compose v2.24+, ~4 GB RAM for Docker.

```bash
# from the repo root
python shared/generate_sample_data.py
docker compose up -d postgres          # the *data* database on localhost:5432

cd 05-airflow-pipelines
echo "AIRFLOW_UID=$(id -u)" > .env     # Linux: so ./logs is owned by you
docker compose up airflow-init         # first time: migrate + create admin user
docker compose up -d
```

Open <http://localhost:8080> (user `airflow`, password `airflow`), then:

1. Unpause **`sparkify_postgres_etl`**. Watch seven daily runs appear and complete
   one after another in the Grid view.
2. Check the result:
   `psql -h localhost -U student -d sparkify_airflow -c "SELECT COUNT(*), COUNT(song_id) FROM songplays"`
   gives the same 3,802 / 2,756 as projects 01, 03 and 04.
3. Clear any single day's `load_songplays` task and let it re-run: counts don't change.
4. Unpause **`weather_ingest`**, then query `daily_weather` in the `weather` DB.

The CLI is handy too:

```bash
docker compose run --rm airflow-cli dags list
docker compose run --rm airflow-cli dags test sparkify_postgres_etl 2026-09-03   # runs the whole DAG for that day
```

### Connecting the Redshift DAG (optional)

After `terraform apply` in `03-redshift-warehouse/infra` and running its
`create_tables.py`, add a connection and three variables (Admin → Connections /
Variables in the UI, or with the CLI):

```bash
docker compose run --rm airflow-cli connections add sparkify_redshift \
  --conn-type postgres --conn-host <redshift_host> --conn-port 5439 \
  --conn-schema sparkify --conn-login awsuser --conn-password '<password>'
docker compose run --rm airflow-cli variables set sparkify_raw_bucket <raw_bucket>
docker compose run --rm airflow-cli variables set sparkify_redshift_role_arn <redshift_s3_role_arn>
docker compose run --rm airflow-cli variables set sparkify_aws_region us-east-1
```

Then unpause `sparkify_redshift_etl`.

## How things are wired

- **Connections** for the local databases are defined as JSON env vars
  (`AIRFLOW_CONN_SPARKIFY_POSTGRES`, `AIRFLOW_CONN_WEATHER_POSTGRES`) in
  `docker-compose.yaml`. `host.docker.internal` reaches the Postgres running on your
  machine from inside the containers.
- The **whole repo** is mounted read-only at `/opt/airflow/projects`, so DAGs read
  `../data` and import code from projects 03 and 06 (`sparkify.load_project_module`).
- `plugins/` is on Airflow's `PYTHONPATH`, which is why DAGs can `import sparkify`.
- The compose file is the official one, trimmed to the **LocalExecutor** (no Redis
  or Celery workers), which is plenty for a laptop.

## Testing DAGs

`tests/test_dag_integrity.py` loads every DAG with `DagBag` and checks there are no
import errors, every task has retries, and the dependencies are what we expect.
Run it in a virtualenv with Airflow installed (see `requirements.txt` for the
constraints-file install):

```bash
SPARKIFY_PROJECTS_DIR=.. pytest tests
```

## Things to try next

- Add an `on_failure_callback` that posts to Slack, or an SLA-style check with a
  deadline alert.
- Make `stage_songs` a separate weekly DAG and trigger the daily load from it with
  **Assets** (`schedule=[Asset("sparkify://catalog")]`).
- Replace the Redshift `LoadTableOperator`s with a single `SQLExecuteQueryOperator`
  and compare readability.
- Run project 04's Spark job from Airflow with the Amazon provider's
  `EmrServerlessStartJobOperator`.
