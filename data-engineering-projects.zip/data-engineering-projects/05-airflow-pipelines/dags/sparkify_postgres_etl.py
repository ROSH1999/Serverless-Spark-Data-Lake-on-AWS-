"""Daily Sparkify ETL into Postgres: one run per day of activity logs.

    create_tables ─┬─ stage_songs ── load_artists ── load_songs ──┐
                   └─ stage_events ─┬─ load_users ────────────────┼─ load_songplays ── quality_checks
                                    └─ load_time ─────────────────┘

Each run stages *its own day* (from the data interval) and upserts into the star
schema, so you can backfill, re-run any day, or clear a task and it all
converges to the same result.

Unpause it and Airflow "catches up": one run per day from START to END below.
"""

from __future__ import annotations

import os
from datetime import datetime, timedelta, timezone

from airflow.providers.common.sql.operators.sql import SQLExecuteQueryOperator
from airflow.sdk import DAG

from sparkify import postgres_sql as sql
from sparkify.operators import DataQualityOperator, LoadTableOperator, StageJsonToPostgresOperator

CONN_ID = "sparkify_postgres"  # defined in docker-compose.yaml via AIRFLOW_CONN_SPARKIFY_POSTGRES

# The sample data generator writes 7 days starting 2026-09-01 by default.
START = datetime.fromisoformat(os.getenv("SPARKIFY_START_DATE", "2026-09-01")).replace(tzinfo=timezone.utc)
END = datetime.fromisoformat(os.getenv("SPARKIFY_END_DATE", "2026-09-07")).replace(tzinfo=timezone.utc)

# The day a run processes. Scheduled/backfill runs: the start of their daily
# interval. Manual runs (`airflow dags test <dag> 2026-09-03`): the date given.
DAY = "{{ data_interval_start.strftime('%Y-%m-%d') }}"
DAY_FILTER = f"(start_time AT TIME ZONE 'UTC')::date = DATE '{DAY}'"

default_args = {
    "owner": "data-eng",
    "retries": 2,
    "retry_delay": timedelta(minutes=1),
    "depends_on_past": False,
}

with DAG(
    dag_id="sparkify_postgres_etl",
    description="Stage one day of Sparkify JSON and load the Postgres star schema",
    schedule="@daily",
    start_date=START,
    end_date=END,
    catchup=True,          # backfill every day between START and END
    max_active_runs=1,     # staging tables are shared, so runs must not overlap
    default_args=default_args,
    tags=["sparkify", "postgres", "etl"],
    doc_md=__doc__,
) as dag:
    create_tables = SQLExecuteQueryOperator(
        task_id="create_tables",
        conn_id=CONN_ID,
        sql=sql.CREATE_TABLES,
    )

    # Small catalog: restaged in full each run. A real catalog would get its own DAG.
    stage_songs = StageJsonToPostgresOperator(
        task_id="stage_songs",
        conn_id=CONN_ID,
        table="staging_songs",
        path="song_data",
    )

    # Only this run's day, e.g. log_data/2026/09/2026-09-03-events.json
    stage_events = StageJsonToPostgresOperator(
        task_id="stage_events",
        conn_id=CONN_ID,
        table="staging_events",
        path="log_data/{{ data_interval_start.strftime('%Y/%m') }}/" + DAY + "-events.json",
    )

    load_artists = LoadTableOperator(task_id="load_artists", conn_id=CONN_ID, table="artists", sql=sql.LOAD_ARTISTS)
    load_songs = LoadTableOperator(task_id="load_songs", conn_id=CONN_ID, table="songs", sql=sql.LOAD_SONGS)
    load_users = LoadTableOperator(task_id="load_users", conn_id=CONN_ID, table="users", sql=sql.LOAD_USERS)
    load_time = LoadTableOperator(task_id="load_time", conn_id=CONN_ID, table="time", sql=sql.LOAD_TIME)
    load_songplays = LoadTableOperator(
        task_id="load_songplays", conn_id=CONN_ID, table="songplays", sql=sql.LOAD_SONGPLAYS
    )

    quality_checks = DataQualityOperator(
        task_id="quality_checks",
        conn_id=CONN_ID,
        checks=[
            {
                "name": "plays loaded for this day",
                "sql": f"SELECT COUNT(*) FROM songplays WHERE {DAY_FILTER}",
                "op": "gt", "value": 0,
            },
            {"name": "no plays without a user", "sql": "SELECT COUNT(*) FROM songplays WHERE user_id IS NULL",
             "op": "eq", "value": 0},
            {"name": "valid levels", "sql": "SELECT COUNT(*) FROM users WHERE level NOT IN ('free', 'paid')",
             "op": "eq", "value": 0},
            {
                "name": "catalog match rate >= 50% today",
                "sql": "SELECT COALESCE(100.0 * COUNT(song_id) / NULLIF(COUNT(*), 0), 0) "
                       f"FROM songplays WHERE {DAY_FILTER}",
                "op": "ge", "value": 50,
            },
        ],
    )

    create_tables >> [stage_songs, stage_events]
    stage_songs >> load_artists >> load_songs
    stage_events >> [load_users, load_time]
    [load_songs, load_users, load_time] >> load_songplays >> quality_checks
