"""Daily Sparkify ETL from S3 into Redshift (the cloud version of sparkify_postgres_etl).

Reuses the warehouse SQL from project 03 (03-redshift-warehouse/sql_queries.py):

    stage_songs ──┐                ┌─ load_users ──┐
                  ├─ load_artists ─┼─ load_songs ──┼─ load_songplays ── quality_checks
    stage_events ─┘                └─ load_time ───┘

Prerequisites (see the README): project 03's infrastructure is up, the tables
exist (03-redshift-warehouse/create_tables.py), and you've set
  * connection  sparkify_redshift   (type Postgres or Amazon Redshift, port 5439)
  * variables   sparkify_raw_bucket, sparkify_redshift_role_arn, sparkify_aws_region
The DAG is paused by default. Unpause it once those exist.
"""

from __future__ import annotations

import os
from datetime import datetime, timedelta, timezone

from airflow.sdk import DAG

from sparkify import load_project_module
from sparkify.operators import DataQualityOperator, LoadTableOperator, StageToRedshiftOperator

CONN_ID = "sparkify_redshift"
q = load_project_module("03-redshift-warehouse", "sql_queries")
TRANSFORMS = dict(q.TRANSFORMS)

START = datetime.fromisoformat(os.getenv("SPARKIFY_START_DATE", "2026-09-01")).replace(tzinfo=timezone.utc)
END = datetime.fromisoformat(os.getenv("SPARKIFY_END_DATE", "2026-09-07")).replace(tzinfo=timezone.utc)

DAY = "{{ data_interval_start.strftime('%Y-%m-%d') }}"  # the day this run processes

S3 = {
    "s3_bucket": "{{ var.value.sparkify_raw_bucket }}",
    "iam_role_arn": "{{ var.value.sparkify_redshift_role_arn }}",
    "region": "{{ var.value.get('sparkify_aws_region', 'us-east-1') }}",
}

with DAG(
    dag_id="sparkify_redshift_etl",
    description="COPY one day of Sparkify JSON from S3 into Redshift and load the star schema",
    schedule="@daily",
    start_date=START,
    end_date=END,
    catchup=True,
    max_active_runs=1,
    is_paused_upon_creation=True,
    default_args={"owner": "data-eng", "retries": 2, "retry_delay": timedelta(minutes=2)},
    tags=["sparkify", "redshift", "aws", "etl"],
    doc_md=__doc__,
) as dag:
    stage_songs = StageToRedshiftOperator(
        task_id="stage_songs", conn_id=CONN_ID, table="staging_songs",
        s3_key="raw/song_data/", json_option="auto", **S3,
    )
    stage_events = StageToRedshiftOperator(
        task_id="stage_events", conn_id=CONN_ID, table="staging_events",
        s3_key="raw/log_data/{{ data_interval_start.strftime('%Y/%m') }}/" + DAY + "-events.json",
        json_option="auto ignorecase", **S3,
    )

    load_artists = LoadTableOperator(task_id="load_artists", conn_id=CONN_ID, table="artists",
                                     sql=TRANSFORMS["artists"])
    load_songs = LoadTableOperator(task_id="load_songs", conn_id=CONN_ID, table="songs",
                                   sql=TRANSFORMS["songs"])
    load_time = LoadTableOperator(task_id="load_time", conn_id=CONN_ID, table="time",
                                  sql=TRANSFORMS["time"])
    # DELETE + INSERT in one transaction = upsert on a warehouse without enforced keys.
    load_users = LoadTableOperator(task_id="load_users", conn_id=CONN_ID, table="users",
                                   sql=[TRANSFORMS["users (delete changed)"], TRANSFORMS["users"]])
    load_songplays = LoadTableOperator(task_id="load_songplays", conn_id=CONN_ID, table="songplays",
                                       sql=TRANSFORMS["songplays"])

    quality_checks = DataQualityOperator(
        task_id="quality_checks",
        conn_id=CONN_ID,
        checks=[
            {"name": "events staged", "sql": "SELECT COUNT(*) FROM staging_events", "op": "gt", "value": 0},
            {"name": "plays loaded for this day",
             "sql": f"SELECT COUNT(*) FROM songplays WHERE TRUNC(start_time) = '{DAY}'",
             "op": "gt", "value": 0},
            {"name": "no duplicate users", "sql": "SELECT COUNT(*) - COUNT(DISTINCT user_id) FROM users",
             "op": "eq", "value": 0},
            {"name": "no duplicate plays",
             "sql": "SELECT COUNT(*) FROM (SELECT user_id, session_id, start_time FROM songplays "
                    "GROUP BY 1, 2, 3 HAVING COUNT(*) > 1) d",
             "op": "eq", "value": 0},
        ],
    )

    [stage_songs, stage_events] >> load_artists
    load_artists >> [load_songs, load_users, load_time]
    [load_songs, load_users, load_time] >> load_songplays >> quality_checks
