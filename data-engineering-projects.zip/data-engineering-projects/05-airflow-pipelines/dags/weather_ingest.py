"""Hourly weather ingestion with the TaskFlow API and dynamic task mapping.

Reuses the API client from project 06 (06-api-to-postgres/weather.py) as-is:
Airflow adds scheduling, retries per city, parallelism and a run history.

    ensure_schema ─► cities ─► fetch[city] ×5 ─► transform[city] ×5 ─► load ─► check_freshness
                               (mapped at runtime: one task instance per city)
"""

from __future__ import annotations

from dataclasses import asdict
from datetime import datetime, timedelta, timezone

from airflow.providers.postgres.hooks.postgres import PostgresHook
from airflow.sdk import dag, task

from sparkify import PROJECTS_DIR, load_project_module

CONN_ID = "weather_postgres"
weather = load_project_module("06-api-to-postgres", "weather")

COLUMNS = ["city", "observed_at", "latitude", "longitude", "temperature_c", "relative_humidity_pct",
           "precipitation_mm", "wind_speed_kmh", "is_forecast"]


@dag(
    dag_id="weather_ingest",
    schedule="@hourly",
    start_date=datetime(2026, 9, 1, tzinfo=timezone.utc),
    catchup=False,  # the API returns a rolling window; no need to replay old hours
    max_active_runs=1,
    default_args={"owner": "data-eng", "retries": 2, "retry_delay": timedelta(minutes=2)},
    tags=["weather", "api", "postgres"],
    doc_md=__doc__,
)
def weather_ingest():
    @task
    def ensure_schema() -> None:
        sql = (PROJECTS_DIR / "06-api-to-postgres" / "schema.sql").read_text()
        PostgresHook(postgres_conn_id=CONN_ID).run(sql)

    @task
    def cities() -> list[dict]:
        return [asdict(c) for c in weather.CITIES]

    # Each city is its own task instance: one flaky city retries alone.
    @task(retries=3, retry_exponential_backoff=True, retry_delay=timedelta(seconds=30))
    def fetch(city: dict) -> dict:
        payload = weather.fetch_hourly(weather.City(**city), past_days=2, forecast_days=1)
        return {"city": city, "payload": payload}

    @task
    def transform(item: dict) -> list[dict]:
        rows, problems = weather.to_rows(weather.City(**item["city"]), item["payload"])
        for p in problems:
            print(f"rejected: {p}")
        # XComs are stored as JSON: send timestamps as ISO strings.
        return [{**r, "observed_at": r["observed_at"].isoformat()} for r in rows]

    @task
    def load(rows_per_city: list[list[dict]]) -> int:
        rows = [tuple(r[c] for c in COLUMNS) for city_rows in rows_per_city for r in city_rows]
        # replace=True turns the INSERT into INSERT ... ON CONFLICT (city, observed_at) DO UPDATE
        PostgresHook(postgres_conn_id=CONN_ID).insert_rows(
            "hourly_weather", rows, target_fields=COLUMNS, replace=True, replace_index=["city", "observed_at"],
        )
        print(f"upserted {len(rows)} rows")
        return len(rows)

    @task
    def check_freshness(max_age_hours: int = 3) -> None:
        latest = PostgresHook(postgres_conn_id=CONN_ID).get_first(
            "SELECT city, MAX(observed_at) FROM hourly_weather WHERE NOT is_forecast "
            "GROUP BY city ORDER BY 2 ASC LIMIT 1"
        )
        if latest is None:
            raise ValueError("hourly_weather is empty")
        city, ts = latest
        age = datetime.now(timezone.utc) - ts
        if age > timedelta(hours=max_age_hours):
            raise ValueError(f"{city} data is stale: newest observation is {age} old")
        print(f"least recently updated city: {city}, newest observation {ts} ({age} old)")

    loaded = load(transform.expand(item=fetch.expand(city=cities())))
    ensure_schema() >> loaded >> check_freshness()


weather_ingest()
