"""Reusable building blocks for the Sparkify DAGs.

Airflow puts the plugins/ folder on sys.path, so DAGs can `from sparkify.operators import ...`.
"""

import importlib.util
import os
import sys
from pathlib import Path
from types import ModuleType

PROJECTS_DIR = Path(os.getenv("SPARKIFY_PROJECTS_DIR", "/opt/airflow/projects"))


def load_project_module(project: str, module: str) -> ModuleType:
    """Import a module from another project in this repo by file path.

    e.g. load_project_module("06-api-to-postgres", "weather") reuses the API
    client from project 06 without copying it. Loading by path avoids clashes
    between same-named modules (several projects have a `sql_queries.py`).
    """
    path = PROJECTS_DIR / project / f"{module}.py"
    if not path.exists():
        raise FileNotFoundError(f"{path} not found. Is the repo mounted at {PROJECTS_DIR}?")
    spec = importlib.util.spec_from_file_location(f"{project.replace('-', '_')}_{module}", path)
    mod = importlib.util.module_from_spec(spec)
    # Register before executing: dataclasses (and pickling) look the module up by name.
    sys.modules[spec.name] = mod
    spec.loader.exec_module(mod)
    return mod
