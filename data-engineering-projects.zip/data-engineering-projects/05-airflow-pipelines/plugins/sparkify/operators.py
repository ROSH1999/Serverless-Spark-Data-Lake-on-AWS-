"""Custom operators for the Sparkify pipelines.

Writing a few small, reusable operators (instead of one giant PythonOperator)
keeps DAG files declarative: each task says *what* to do, the operator knows
*how*. All of them work with any SQL connection Airflow knows (Postgres,
Redshift, ...), because they ask the connection for its matching hook.
"""

from __future__ import annotations

import json
import operator
import os
from pathlib import Path
from typing import Any, Sequence

from airflow.sdk import BaseHook, BaseOperator

PROJECTS_DIR = Path(os.getenv("SPARKIFY_PROJECTS_DIR", "/opt/airflow/projects"))
DATA_DIR = Path(os.getenv("SPARKIFY_DATA_DIR", PROJECTS_DIR / "data"))


def sql_hook(conn_id: str):
    """Return the DB-API hook for a connection (PostgresHook, RedshiftSQLHook, ...)."""
    return BaseHook.get_connection(conn_id).get_hook()


# ----------------------------------------------------------------- staging

class StageJsonToPostgresOperator(BaseOperator):
    """Load local JSON / JSON-Lines files into a staging table.

    `path` is relative to DATA_DIR and templated, so one DAG run can stage one
    day: path="log_data/{{ ds[:4] }}/{{ ds[5:7] }}/{{ ds }}-events.json".
    JSON keys are matched to columns case-insensitively (userId -> userid).
    """

    template_fields: Sequence[str] = ("path",)
    ui_color = "#e6f2ea"

    def __init__(self, *, conn_id: str, table: str, path: str, truncate: bool = True, **kwargs) -> None:
        super().__init__(**kwargs)
        self.conn_id, self.table, self.path, self.truncate = conn_id, table, path, truncate

    @staticmethod
    def _records(file: Path):
        text = file.read_text(encoding="utf-8").strip()
        if not text:
            return
        if text.startswith("{") and "\n" not in text:  # one JSON object per file
            yield json.loads(text)
            return
        for line in text.splitlines():  # JSON Lines
            if line.strip():
                yield json.loads(line)

    def execute(self, context) -> int:
        source = DATA_DIR / self.path
        files = sorted(source.rglob("*.json")) if source.is_dir() else [source]
        missing = [f for f in files if not f.exists()]
        if not files or missing:
            # Missing input is an error, not "nothing to do": fail loudly so it gets noticed.
            raise FileNotFoundError(f"No input at {source}")

        hook = sql_hook(self.conn_id)
        columns = [r[0] for r in hook.get_records(
            "SELECT column_name FROM information_schema.columns "
            "WHERE table_name = %s ORDER BY ordinal_position", parameters=(self.table,))]
        rows = []
        for f in files:
            for rec in self._records(f):
                lowered = {k.lower(): v for k, v in rec.items()}
                rows.append(tuple(lowered.get(c) for c in columns))

        if self.truncate:
            hook.run(f"TRUNCATE {self.table}")
        hook.insert_rows(self.table, rows, target_fields=columns, commit_every=2000)
        self.log.info("Staged %d rows from %d file(s) into %s", len(rows), len(files), self.table)
        return len(rows)


class StageToRedshiftOperator(BaseOperator):
    """COPY JSON from S3 into a Redshift staging table using an IAM role.

    The S3 key is templated so each run can load just its own partition. Bucket,
    role and region are templated too, so they can come from Airflow Variables
    ("{{ var.value.sparkify_raw_bucket }}") without a DB lookup at parse time.
    """

    template_fields: Sequence[str] = ("s3_bucket", "s3_key", "iam_role_arn", "region")
    ui_color = "#fbe5d6"

    COPY_SQL = """
        COPY {table}
        FROM 's3://{bucket}/{key}'
        IAM_ROLE '{role}'
        FORMAT AS JSON '{json_option}'
        REGION '{region}'
        TRUNCATECOLUMNS COMPUPDATE OFF STATUPDATE OFF
    """

    def __init__(self, *, conn_id: str, table: str, s3_bucket: str, s3_key: str, iam_role_arn: str,
                 region: str, json_option: str = "auto ignorecase", truncate: bool = True, **kwargs) -> None:
        super().__init__(**kwargs)
        self.conn_id, self.table = conn_id, table
        self.s3_bucket, self.s3_key = s3_bucket, s3_key
        self.iam_role_arn, self.region = iam_role_arn, region
        self.json_option, self.truncate = json_option, truncate

    def execute(self, context) -> None:
        sql = self.COPY_SQL.format(table=self.table, bucket=self.s3_bucket, key=self.s3_key,
                                   role=self.iam_role_arn, json_option=self.json_option, region=self.region)
        statements = ([f"TRUNCATE {self.table}"] if self.truncate else []) + [sql]
        self.log.info("COPY s3://%s/%s -> %s", self.s3_bucket, self.s3_key, self.table)
        sql_hook(self.conn_id).run(statements)


# ------------------------------------------------------------------ loading

class LoadTableOperator(BaseOperator):
    """Run one or more INSERT ... SELECT statements that load a fact or dimension.

    mode="append"  -> run the SQL as-is (it should be idempotent, e.g. ON CONFLICT)
    mode="replace" -> TRUNCATE the table first, in the same transaction
    """

    template_fields: Sequence[str] = ("sql",)
    template_ext: Sequence[str] = (".sql",)
    ui_color = "#e8eef9"

    def __init__(self, *, conn_id: str, table: str, sql: str | list[str], mode: str = "append", **kwargs) -> None:
        super().__init__(**kwargs)
        if mode not in {"append", "replace"}:
            raise ValueError("mode must be 'append' or 'replace'")
        self.conn_id, self.table, self.sql, self.mode = conn_id, table, sql, mode

    def execute(self, context) -> int:
        hook = sql_hook(self.conn_id)
        statements = [self.sql] if isinstance(self.sql, str) else list(self.sql)
        if self.mode == "replace":
            statements.insert(0, f"TRUNCATE {self.table}")
        hook.run(statements)  # one connection, committed once at the end
        count = hook.get_first(f"SELECT COUNT(*) FROM {self.table}")[0]
        self.log.info("%s now has %d rows", self.table, count)
        return count


# ------------------------------------------------------------------ quality

class DataQualityOperator(BaseOperator):
    """Run SQL checks that each return a single number, and fail on any miss.

    checks = [{"name": "...", "sql": "SELECT COUNT(*) ...", "op": "gt", "value": 0}, ...]
    op is one of: eq, ne, gt, ge, lt, le. Checks are templated, so they can refer
    to the run's data interval.
    """

    template_fields: Sequence[str] = ("checks",)
    ui_color = "#fff3cd"
    OPS = {"eq": operator.eq, "ne": operator.ne, "gt": operator.gt,
           "ge": operator.ge, "lt": operator.lt, "le": operator.le}

    def __init__(self, *, conn_id: str, checks: list[dict[str, Any]], **kwargs) -> None:
        super().__init__(**kwargs)
        for c in checks:
            if c.get("op") not in self.OPS:
                raise ValueError(f"check {c.get('name')!r}: op must be one of {sorted(self.OPS)}")
        self.conn_id, self.checks = conn_id, checks

    def execute(self, context) -> None:
        hook = sql_hook(self.conn_id)
        failures = []
        for c in self.checks:
            result = hook.get_first(c["sql"])
            actual = result[0] if result else None
            passed = actual is not None and self.OPS[c["op"]](actual, c["value"])
            self.log.info("[%s] %s: %s %s %s", "PASS" if passed else "FAIL", c["name"], actual, c["op"], c["value"])
            if not passed:
                failures.append(f"{c['name']} (got {actual}, expected {c['op']} {c['value']})")
        if failures:
            raise ValueError("Data quality checks failed: " + "; ".join(failures))
