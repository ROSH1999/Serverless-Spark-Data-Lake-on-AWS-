"""SQL for the Postgres version of the Sparkify pipeline run by Airflow.

Same star schema as project 01, but loaded the "ELT" way, like project 03:
JSON -> staging tables -> INSERT ... SELECT inside the database. Each DAG run
stages exactly one day of events, so every transform below only ever sees that
day's data, and ON CONFLICT keeps re-runs (and backfills) idempotent.
"""

CREATE_TABLES = [
    """
    CREATE TABLE IF NOT EXISTS staging_events (
        artist TEXT, auth TEXT, firstname TEXT, gender TEXT, iteminsession INTEGER,
        lastname TEXT, length DOUBLE PRECISION, level TEXT, location TEXT, method TEXT,
        page TEXT, registration DOUBLE PRECISION, sessionid INTEGER, song TEXT,
        status INTEGER, ts BIGINT, useragent TEXT, userid TEXT
    )
    """,
    """
    CREATE TABLE IF NOT EXISTS staging_songs (
        num_songs INTEGER, artist_id TEXT, artist_latitude DOUBLE PRECISION,
        artist_longitude DOUBLE PRECISION, artist_location TEXT, artist_name TEXT,
        song_id TEXT, title TEXT, duration DOUBLE PRECISION, year INTEGER
    )
    """,
    """
    CREATE TABLE IF NOT EXISTS users (
        user_id INTEGER PRIMARY KEY, first_name TEXT, last_name TEXT,
        gender CHAR(1), level TEXT NOT NULL,
        last_seen_at TIMESTAMPTZ NOT NULL   -- lets out-of-order backfills keep the newest level
    )
    """,
    """
    CREATE TABLE IF NOT EXISTS artists (
        artist_id TEXT PRIMARY KEY, name TEXT NOT NULL, location TEXT,
        latitude DOUBLE PRECISION, longitude DOUBLE PRECISION
    )
    """,
    """
    CREATE TABLE IF NOT EXISTS songs (
        song_id TEXT PRIMARY KEY, title TEXT NOT NULL,
        artist_id TEXT NOT NULL REFERENCES artists (artist_id),
        year SMALLINT, duration NUMERIC(10, 5) NOT NULL
    )
    """,
    """
    CREATE TABLE IF NOT EXISTS time (
        start_time TIMESTAMPTZ PRIMARY KEY, hour SMALLINT, day SMALLINT, week SMALLINT,
        month SMALLINT, year SMALLINT, weekday SMALLINT
    )
    """,
    """
    CREATE TABLE IF NOT EXISTS songplays (
        songplay_id BIGSERIAL PRIMARY KEY,
        start_time  TIMESTAMPTZ NOT NULL REFERENCES time (start_time),
        user_id     INTEGER NOT NULL REFERENCES users (user_id),
        level       TEXT NOT NULL,
        song_id     TEXT REFERENCES songs (song_id),
        artist_id   TEXT REFERENCES artists (artist_id),
        session_id  INTEGER NOT NULL,
        location    TEXT,
        user_agent  TEXT,
        CONSTRAINT songplays_natural_key UNIQUE (user_id, session_id, start_time)
    )
    """,
]

# Song plays by logged-in users in today's staging data.
_PLAYS = """
    SELECT DISTINCT ON (userid, sessionid, iteminsession, ts)
           to_timestamp(ts / 1000.0)  AS start_time,
           CAST(userid AS INTEGER)    AS user_id,
           level, song, artist, length, sessionid, location, useragent, ts,
           firstname, lastname, gender
    FROM staging_events
    WHERE page = 'NextSong' AND NULLIF(TRIM(userid), '') IS NOT NULL
"""

LOAD_ARTISTS = """
INSERT INTO artists (artist_id, name, location, latitude, longitude)
SELECT DISTINCT ON (artist_id)
       artist_id, TRIM(artist_name), NULLIF(TRIM(artist_location), ''), artist_latitude, artist_longitude
FROM staging_songs
WHERE artist_id IS NOT NULL
ORDER BY artist_id, (NULLIF(TRIM(artist_location), '') IS NULL), song_id
ON CONFLICT (artist_id) DO UPDATE SET
    name     = EXCLUDED.name,
    location = COALESCE(EXCLUDED.location, artists.location)
"""

LOAD_SONGS = """
INSERT INTO songs (song_id, title, artist_id, year, duration)
SELECT DISTINCT ON (song_id) song_id, TRIM(title), artist_id, NULLIF(year, 0), duration
FROM staging_songs
WHERE song_id IS NOT NULL
ORDER BY song_id
ON CONFLICT (song_id) DO NOTHING
"""

LOAD_TIME = f"""
INSERT INTO time (start_time, hour, day, week, month, year, weekday)
SELECT DISTINCT start_time,
       EXTRACT(hour FROM start_time AT TIME ZONE 'UTC'),
       EXTRACT(day FROM start_time AT TIME ZONE 'UTC'),
       EXTRACT(week FROM start_time AT TIME ZONE 'UTC'),
       EXTRACT(month FROM start_time AT TIME ZONE 'UTC'),
       EXTRACT(year FROM start_time AT TIME ZONE 'UTC'),
       EXTRACT(isodow FROM start_time AT TIME ZONE 'UTC') - 1      -- 0 = Monday
FROM ({_PLAYS}) plays
ON CONFLICT (start_time) DO NOTHING
"""

# Latest level per user within the day. The WHERE clause on the update makes
# backfills safe: re-running an *older* day can't overwrite a newer level.
LOAD_USERS = f"""
INSERT INTO users (user_id, first_name, last_name, gender, level, last_seen_at)
SELECT DISTINCT ON (user_id) user_id, firstname, lastname, gender, level, start_time
FROM ({_PLAYS}) plays
ORDER BY user_id, ts DESC
ON CONFLICT (user_id) DO UPDATE SET
    first_name   = EXCLUDED.first_name,
    last_name    = EXCLUDED.last_name,
    gender       = EXCLUDED.gender,
    level        = EXCLUDED.level,
    last_seen_at = EXCLUDED.last_seen_at
WHERE EXCLUDED.last_seen_at >= users.last_seen_at
"""

LOAD_SONGPLAYS = f"""
INSERT INTO songplays (start_time, user_id, level, song_id, artist_id, session_id, location, user_agent)
SELECT p.start_time, p.user_id, p.level, cat.song_id, cat.artist_id, p.sessionid, p.location, p.useragent
FROM ({_PLAYS}) p
LEFT JOIN LATERAL (
    SELECT s.song_id, s.artist_id
    FROM songs s
    JOIN artists a ON a.artist_id = s.artist_id
    WHERE LOWER(s.title) = LOWER(p.song)
      AND LOWER(a.name) = LOWER(p.artist)
      AND ROUND(s.duration, 2) = ROUND(CAST(p.length AS NUMERIC), 2)
    ORDER BY s.song_id
    LIMIT 1
) cat ON TRUE
ON CONFLICT ON CONSTRAINT songplays_natural_key DO NOTHING
"""
