"""DAG integrity tests: every DAG imports cleanly and has the shape we expect.

Run from this folder with Airflow installed (see README):

    SPARKIFY_PROJECTS_DIR=.. pytest tests
"""

import os
import sys
from pathlib import Path

import pytest

HERE = Path(__file__).resolve().parents[1]
os.environ.setdefault("SPARKIFY_PROJECTS_DIR", str(HERE.parent))
sys.path.insert(0, str(HERE / "plugins"))

pytest.importorskip("airflow")
from airflow.models import DagBag  # noqa: E402


@pytest.fixture(scope="module")
def dagbag():
    return DagBag(dag_folder=str(HERE / "dags"))


def test_no_import_errors(dagbag):
    assert dagbag.import_errors == {}


def test_expected_dags(dagbag):
    assert set(dagbag.dag_ids) == {"sparkify_postgres_etl", "sparkify_redshift_etl", "weather_ingest"}


@pytest.mark.parametrize("dag_id", ["sparkify_postgres_etl", "sparkify_redshift_etl", "weather_ingest"])
def test_dags_have_retries_tags_and_no_overlap(dagbag, dag_id):
    dag = dagbag.get_dag(dag_id)
    assert dag.tags, "tag every DAG so it can be found in the UI"
    assert dag.max_active_runs == 1
    for t in dag.tasks:
        assert t.retries >= 1, f"{t.task_id} has no retries"


def test_postgres_etl_ordering(dagbag):
    dag = dagbag.get_dag("sparkify_postgres_etl")
    sp = dag.get_task("load_songplays")
    assert {"load_songs", "load_users", "load_time"} <= sp.upstream_task_ids
    assert dag.get_task("quality_checks").upstream_task_ids == {"load_songplays"}
    assert dag.catchup is True
