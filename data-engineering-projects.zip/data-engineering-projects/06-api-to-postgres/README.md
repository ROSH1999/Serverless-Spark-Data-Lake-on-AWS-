# 06 · API → Postgres: a production-minded ingestion script

**What you'll learn:** calling a REST API defensively (timeouts, retries with
backoff, error messages that say *why*), validating responses before trusting them,
reshaping column-oriented JSON into rows, idempotent upserts, and keeping an audit
trail of every run.

## The source

[Open-Meteo](https://open-meteo.com/en/docs) is a free weather API (no key needed
for non-commercial use). One request returns hourly data for one location in a
*column-oriented* shape:

```json
{
  "hourly_units": {"time": "iso8601", "temperature_2m": "°C", ...},
  "hourly": {
    "time":           ["2026-10-01T00:00", "2026-10-01T01:00", ...],
    "temperature_2m": [11.4, 10.9, ...],
    "precipitation":  [0.0, null, ...]
  }
}
```

We ask for `past_days=2` and `forecast_days=1` with `timezone=UTC` for five cities.

## The target tables (`schema.sql`)

| Object | Grain / purpose |
|---|---|
| `hourly_weather` | one row per **(city, hour)**, the primary key. Has `is_forecast` so future hours can be told apart |
| `ingestion_runs` | one row per run: status, rows received/changed/rejected, error message |
| `daily_weather` (view) | min/max/avg temperature, total rain, max wind per city per day, from observed hours only |

## What makes it robust

| Concern | How it's handled | Where |
|---|---|---|
| Transient failures (timeouts, 429, 5xx) | `urllib3` `Retry` with exponential backoff, honours `Retry-After` | `weather.make_session` |
| Permanent failures (400) | not retried; the API's `reason` is surfaced in the error | `weather.fetch_hourly` |
| API changes shape or units | fail fast: missing fields, mismatched array lengths, °C→°F | `weather.validate_payload` |
| Garbage values | out-of-range rows are **rejected and counted**, not loaded | `weather.to_rows` |
| Re-runs / overlapping windows | `INSERT … ON CONFLICT DO UPDATE … WHERE … IS DISTINCT FROM` | `ingest.UPSERT` |
| Forecast becomes observation | the same key is updated later; `is_forecast` flips to false | upsert |
| One city failing | each city is its own transaction; run ends `partial` instead of losing everything | `ingest.run` |
| "Did it work last night?" | `SELECT * FROM ingestion_runs ORDER BY run_id DESC` | `schema.sql` |

`weather.py` has **no database code**, which is why the Airflow DAG in project 05
can import and reuse it unchanged.

## Run it

```bash
docker compose up -d postgres          # from the repo root; creates the "weather" DB

cd 06-api-to-postgres
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt

python ingest.py                       # all five cities
python ingest.py                       # run again: "0 changed" proves idempotency
python ingest.py --city London --past-days 7

psql -h localhost -U student -d weather \
  -c "SELECT * FROM daily_weather ORDER BY city, day_utc" \
  -c "SELECT run_id, status, rows_received, rows_changed, rows_rejected FROM ingestion_runs ORDER BY run_id DESC LIMIT 5"
```

No internet? Load the saved response instead:

```bash
python ingest.py --from-file tests/fixtures/open_meteo_london.json --city London
```

Tests use a stub HTTP session and the fixture, so they need neither network nor
database: `pip install pytest && pytest tests`.

## Scheduling

- **cron** (simplest): `0 * * * * cd /path/06-api-to-postgres && .venv/bin/python ingest.py >> ingest.log 2>&1`
- **Airflow**: see `05-airflow-pipelines/dags/weather_ingest.py`, which reuses this
  module with TaskFlow tasks, retries and alerting.

## Things to try next

- Add a city table instead of the hard-coded list, and ingest whatever it contains.
- Switch the upsert to `COPY` into a temp table + one `INSERT … SELECT … ON CONFLICT`
  and compare speed with `--past-days 92`.
- Pull a second API (e.g. air quality from Open-Meteo's air-quality endpoint) and
  join it with weather in a view.
