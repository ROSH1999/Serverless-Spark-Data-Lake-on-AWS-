"""Ingest hourly weather from the Open-Meteo API into Postgres.

    python ingest.py                          # all cities in weather.CITIES
    python ingest.py --city London --city Tokyo
    python ingest.py --past-days 7            # backfill a week
    python ingest.py --from-file tests/fixtures/open_meteo_london.json --city London   # offline

Each run:
  1. ensures the tables exist (schema.sql)
  2. records itself in ingestion_runs
  3. fetches each city (with retries), validates, and UPSERTs the rows
  4. marks the run success / partial / failed with counts

It is idempotent: running it twice in a row changes nothing the second time,
because the upsert only touches rows whose values actually changed.
"""

from __future__ import annotations

import argparse
import json
import logging
import os
import sys
from pathlib import Path

import psycopg

import weather

HERE = Path(__file__).resolve().parent
log = logging.getLogger("ingest")

UPSERT = """
INSERT INTO hourly_weather (city, observed_at, latitude, longitude, temperature_c,
                            relative_humidity_pct, precipitation_mm, wind_speed_kmh, is_forecast)
VALUES (%(city)s, %(observed_at)s, %(latitude)s, %(longitude)s, %(temperature_c)s,
        %(relative_humidity_pct)s, %(precipitation_mm)s, %(wind_speed_kmh)s, %(is_forecast)s)
ON CONFLICT (city, observed_at) DO UPDATE SET
    temperature_c         = EXCLUDED.temperature_c,
    relative_humidity_pct = EXCLUDED.relative_humidity_pct,
    precipitation_mm      = EXCLUDED.precipitation_mm,
    wind_speed_kmh        = EXCLUDED.wind_speed_kmh,
    is_forecast           = EXCLUDED.is_forecast,
    ingested_at           = now()
-- Skip no-op updates: keeps ingested_at meaningful and avoids needless writes.
WHERE (hourly_weather.temperature_c, hourly_weather.relative_humidity_pct,
       hourly_weather.precipitation_mm, hourly_weather.wind_speed_kmh, hourly_weather.is_forecast)
      IS DISTINCT FROM
      (EXCLUDED.temperature_c, EXCLUDED.relative_humidity_pct,
       EXCLUDED.precipitation_mm, EXCLUDED.wind_speed_kmh, EXCLUDED.is_forecast)
"""


def connect() -> psycopg.Connection:
    return psycopg.connect(
        host=os.getenv("PGHOST", "localhost"),
        port=int(os.getenv("PGPORT", "5432")),
        user=os.getenv("PGUSER", "student"),
        password=os.getenv("PGPASSWORD", "student"),
        dbname=os.getenv("WEATHER_DB", "weather"),
    )


def upsert(conn: psycopg.Connection, rows: list[dict]) -> int:
    """Upsert rows and return how many were inserted or actually changed."""
    changed = 0
    with conn.cursor() as cur:
        for row in rows:  # per-row so we can count real changes; fine for ~100s of rows
            cur.execute(UPSERT, row)
            changed += cur.rowcount
    return changed


def run(cities: list[weather.City], *, past_days: int, forecast_days: int,
        from_file: Path | None = None) -> str:
    with connect() as conn:
        conn.execute((HERE / "schema.sql").read_text())
        run_id = conn.execute(
            "INSERT INTO ingestion_runs (source) VALUES (%s) RETURNING run_id",
            (str(from_file) if from_file else weather.API_URL,),
        ).fetchone()[0]
        conn.commit()  # make the 'running' row visible even if we crash later

        received = changed = rejected = 0
        errors: list[str] = []
        session = weather.make_session()

        for city in cities:
            try:
                payload = (json.loads(from_file.read_text(encoding="utf-8")) if from_file
                           else weather.fetch_hourly(city, past_days=past_days,
                                                     forecast_days=forecast_days, session=session))
                rows, problems = weather.to_rows(city, payload)
                for p in problems:
                    log.warning("rejected %s", p)
                n = upsert(conn, rows)
                conn.commit()  # one transaction per city: a later failure keeps earlier cities
                received, changed, rejected = received + len(rows), changed + n, rejected + len(problems)
                log.info("%-10s %3d rows received, %3d changed, %d rejected", city.name, len(rows), n, len(problems))
            except Exception as exc:  # keep going with the other cities
                conn.rollback()
                errors.append(f"{city.name}: {exc}")
                log.error("%s failed: %s", city.name, exc)

        status = "success" if not errors else ("partial" if len(errors) < len(cities) else "failed")
        conn.execute(
            """UPDATE ingestion_runs
               SET finished_at = now(), status = %s, rows_received = %s, rows_changed = %s,
                   rows_rejected = %s, message = %s
               WHERE run_id = %s""",
            (status, received, changed, rejected, "; ".join(errors) or None, run_id),
        )
    log.info("run %s finished: %s (%d received, %d changed, %d rejected)",
             run_id, status, received, changed, rejected)
    return status


def main() -> None:
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--city", action="append", help="city name from weather.CITIES (repeatable)")
    p.add_argument("--past-days", type=int, default=2)
    p.add_argument("--forecast-days", type=int, default=1)
    p.add_argument("--from-file", type=Path, help="load a saved API response instead of calling the API")
    args = p.parse_args()

    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)-7s %(message)s")
    by_name = {c.name.lower(): c for c in weather.CITIES}
    try:
        cities = [by_name[n.lower()] for n in args.city] if args.city else weather.CITIES
    except KeyError as exc:
        sys.exit(f"Unknown city {exc}. Choose from: {', '.join(c.name for c in weather.CITIES)}")
    if args.from_file and len(cities) != 1:
        sys.exit("--from-file holds one city's response; pass exactly one --city")

    status = run(cities, past_days=args.past_days, forecast_days=args.forecast_days, from_file=args.from_file)
    sys.exit(0 if status == "success" else 1)


if __name__ == "__main__":
    main()
