-- Tables for the weather ingestion project. Safe to run repeatedly.

CREATE TABLE IF NOT EXISTS hourly_weather (
    city                   TEXT        NOT NULL,
    observed_at            TIMESTAMPTZ NOT NULL,
    latitude               NUMERIC(8, 5) NOT NULL,
    longitude              NUMERIC(8, 5) NOT NULL,
    temperature_c          REAL,
    relative_humidity_pct  REAL,
    precipitation_mm       REAL,
    wind_speed_kmh         REAL,
    -- TRUE while the hour is still in the future. A later run overwrites the
    -- forecast with the observed value for the same (city, observed_at).
    is_forecast            BOOLEAN     NOT NULL,
    ingested_at            TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (city, observed_at)
);

-- One row per run: when it ran, how it went, how much it changed.
-- Answering "did last night's load work?" shouldn't require reading logs.
CREATE TABLE IF NOT EXISTS ingestion_runs (
    run_id         BIGSERIAL   PRIMARY KEY,
    source         TEXT        NOT NULL,
    started_at     TIMESTAMPTZ NOT NULL DEFAULT now(),
    finished_at    TIMESTAMPTZ,
    status         TEXT        NOT NULL DEFAULT 'running'
                   CHECK (status IN ('running', 'success', 'partial', 'failed')),
    rows_received  INTEGER,
    rows_changed   INTEGER,
    rows_rejected  INTEGER,
    message        TEXT
);

-- A "useful table" for analysts: daily stats from observed (not forecast) hours.
CREATE OR REPLACE VIEW daily_weather AS
SELECT city,
       (observed_at AT TIME ZONE 'UTC')::date AS day_utc,
       COUNT(*)                               AS hours,
       ROUND(MIN(temperature_c)::numeric, 1)  AS min_temp_c,
       ROUND(MAX(temperature_c)::numeric, 1)  AS max_temp_c,
       ROUND(AVG(temperature_c)::numeric, 1)  AS avg_temp_c,
       ROUND(SUM(precipitation_mm)::numeric, 1) AS total_precip_mm,
       ROUND(MAX(wind_speed_kmh)::numeric, 1) AS max_wind_kmh
FROM hourly_weather
WHERE NOT is_forecast
GROUP BY city, day_utc;
