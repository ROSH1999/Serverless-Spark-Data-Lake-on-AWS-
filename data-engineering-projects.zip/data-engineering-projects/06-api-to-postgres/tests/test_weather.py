"""Tests for the API client and transform. No network or database needed:
HTTP is faked with a tiny stub session.

    pytest 06-api-to-postgres
"""

import copy
import json
import sys
from datetime import datetime, timezone
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import weather  # noqa: E402

FIXTURE = json.loads((Path(__file__).parent / "fixtures" / "open_meteo_london.json").read_text(encoding="utf-8"))
LONDON = weather.City("London", 51.5072, -0.1276)
NOW = datetime(2026, 10, 2, 12, 30, tzinfo=timezone.utc)


def test_to_rows_shapes_and_flags_forecast():
    rows, problems = weather.to_rows(LONDON, FIXTURE, now=NOW)
    assert len(rows) == 72 and problems == []
    first = rows[0]
    assert first["observed_at"] == datetime(2026, 9, 30, 0, 0, tzinfo=timezone.utc)
    assert set(first) >= {"city", "temperature_c", "relative_humidity_pct", "precipitation_mm", "wind_speed_kmh"}
    assert sum(r["is_forecast"] for r in rows) == 11  # 13:00 .. 23:00 on Oct 2
    assert rows[50]["precipitation_mm"] is None        # nulls pass through as NULL


def test_out_of_range_rows_are_rejected_not_loaded():
    bad = copy.deepcopy(FIXTURE)
    bad["hourly"]["relative_humidity_2m"][3] = 140
    rows, problems = weather.to_rows(LONDON, bad, now=NOW)
    assert len(rows) == 71
    assert "relative_humidity_pct=140" in problems[0]


def test_unit_change_fails_fast():
    bad = copy.deepcopy(FIXTURE)
    bad["hourly_units"]["temperature_2m"] = "°F"
    with pytest.raises(weather.ApiError, match="expected '°C'"):
        weather.to_rows(LONDON, bad)


def test_mismatched_array_lengths_fail_fast():
    bad = copy.deepcopy(FIXTURE)
    bad["hourly"]["wind_speed_10m"].pop()
    with pytest.raises(weather.ApiError, match="wind_speed_10m"):
        weather.to_rows(LONDON, bad)


class StubResponse:
    def __init__(self, status, body):
        self.status_code, self._body = status, body
        self.text = json.dumps(body)

    def json(self):
        return self._body


class StubSession:
    def __init__(self, response):
        self.response, self.calls = response, []

    def get(self, url, params, timeout):
        self.calls.append((url, params))
        return self.response


def test_fetch_sends_expected_params():
    session = StubSession(StubResponse(200, FIXTURE))
    assert weather.fetch_hourly(LONDON, past_days=3, session=session) is FIXTURE
    url, params = session.calls[0]
    assert url == weather.API_URL
    assert params["timezone"] == "UTC" and params["past_days"] == 3
    assert params["hourly"].split(",") == list(weather.HOURLY_FIELDS)


def test_fetch_surfaces_api_error_reason():
    session = StubSession(StubResponse(400, {"error": True, "reason": "Latitude must be in range"}))
    with pytest.raises(weather.ApiError, match="Latitude must be in range"):
        weather.fetch_hourly(LONDON, session=session)
