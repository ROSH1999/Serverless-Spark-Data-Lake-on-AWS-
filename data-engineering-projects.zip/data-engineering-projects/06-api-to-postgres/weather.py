"""Pull hourly weather from the Open-Meteo API and shape it into rows.

This module only talks HTTP and does pure Python transforms, with no database
code, so it's reused unchanged by both ingest.py (plain script) and the Airflow
DAG in project 05.

API docs: https://open-meteo.com/en/docs  (free for non-commercial use, no key)
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone

import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

API_URL = "https://api.open-meteo.com/v1/forecast"

# variable name in the API -> (column name in our table, unit we expect)
HOURLY_FIELDS = {
    "temperature_2m": ("temperature_c", "°C"),
    "relative_humidity_2m": ("relative_humidity_pct", "%"),
    "precipitation": ("precipitation_mm", "mm"),
    "wind_speed_10m": ("wind_speed_kmh", "km/h"),
}

# Sanity bounds. A value outside them is almost certainly a bug, not weather.
BOUNDS = {
    "temperature_c": (-90, 60),
    "relative_humidity_pct": (0, 100),
    "precipitation_mm": (0, 500),
    "wind_speed_kmh": (0, 500),
}


@dataclass(frozen=True)
class City:
    name: str
    latitude: float
    longitude: float


CITIES = [
    City("New York", 40.7128, -74.0060),
    City("London", 51.5072, -0.1276),
    City("Tokyo", 35.6762, 139.6503),
    City("São Paulo", -23.5505, -46.6333),
    City("Sydney", -33.8688, 151.2093),
]


class ApiError(RuntimeError):
    pass


def make_session(retries: int = 3) -> requests.Session:
    """A session that retries transient failures with exponential backoff.

    429 (rate limited) and 5xx are worth retrying; 4xx like 400 (bad request) are
    not, because sending the same bad request again won't fix it.
    """
    retry = Retry(
        total=retries,
        backoff_factor=1,  # 1s, 2s, 4s ...
        status_forcelist=[429, 500, 502, 503, 504],
        allowed_methods=["GET"],
        respect_retry_after_header=True,
    )
    session = requests.Session()
    session.mount("https://", HTTPAdapter(max_retries=retry))
    session.headers["User-Agent"] = "data-engineering-projects/1.0 (learning project)"
    return session


def fetch_hourly(city: City, *, past_days: int = 2, forecast_days: int = 1,
                 session: requests.Session | None = None, timeout: float = 15) -> dict:
    """Call the API once for one city and return the decoded JSON."""
    params = {
        "latitude": city.latitude,
        "longitude": city.longitude,
        "hourly": ",".join(HOURLY_FIELDS),
        "timezone": "UTC",  # store everything in UTC; convert at query time
        "past_days": past_days,
        "forecast_days": forecast_days,
    }
    session = session or make_session()
    resp = session.get(API_URL, params=params, timeout=timeout)
    if resp.status_code >= 400:
        # Open-Meteo explains errors as {"error": true, "reason": "..."}
        try:
            reason = resp.json().get("reason", resp.text)
        except ValueError:
            reason = resp.text
        raise ApiError(f"{city.name}: HTTP {resp.status_code}: {reason}")
    return resp.json()


def validate_payload(payload: dict) -> None:
    """Fail fast if the API response isn't shaped the way we expect."""
    hourly = payload.get("hourly")
    units = payload.get("hourly_units", {})
    if not isinstance(hourly, dict) or "time" not in hourly:
        raise ApiError("response has no 'hourly.time' array")
    n = len(hourly["time"])
    for field, (_, unit) in HOURLY_FIELDS.items():
        if field not in hourly:
            raise ApiError(f"response is missing hourly '{field}'")
        if len(hourly[field]) != n:
            raise ApiError(f"'{field}' has {len(hourly[field])} values but there are {n} timestamps")
        if units.get(field) != unit:
            raise ApiError(f"'{field}' is in '{units.get(field)}', expected '{unit}'")


def to_rows(city: City, payload: dict, *, now: datetime | None = None) -> tuple[list[dict], list[str]]:
    """Turn the column-oriented API response into one dict per hour.

    Returns (rows, problems). Rows that fail sanity checks are dropped and
    described in `problems` instead of silently loaded.
    """
    validate_payload(payload)
    now = now or datetime.now(timezone.utc)
    hourly = payload["hourly"]
    rows, problems = [], []

    for i, ts in enumerate(hourly["time"]):
        # timezone=UTC was requested, so "2026-10-02T13:00" is 13:00 UTC.
        observed_at = datetime.fromisoformat(ts).replace(tzinfo=timezone.utc)
        row = {
            "city": city.name,
            "latitude": city.latitude,
            "longitude": city.longitude,
            "observed_at": observed_at,
            "is_forecast": observed_at > now,
        }
        for field, (column, _) in HOURLY_FIELDS.items():
            row[column] = hourly[field][i]

        values = [row[c] for c, _ in HOURLY_FIELDS.values()]
        if all(v is None for v in values):
            problems.append(f"{city.name} {ts}: all values missing")
            continue
        bad = [c for c, (lo, hi) in BOUNDS.items() if row[c] is not None and not lo <= row[c] <= hi]
        if bad:
            problems.append(f"{city.name} {ts}: out of range {', '.join(f'{c}={row[c]}' for c in bad)}")
            continue
        rows.append(row)
    return rows, problems
