# Data Engineering Projects

Six small, realistic projects that take **raw JSON and API data** and turn it into
**useful tables and pipelines**, mostly in Python. Each one teaches a different
part of the job, and they all share one dataset so you can compare approaches
side by side.

| # | Project | You'll learn | Runs on |
|---|---|---|---|
| 01 | [Song plays into Postgres](01-postgres-song-etl/) | star-schema modeling, Python ETL, idempotent upserts, testable transforms | Docker (Postgres) |
| 02 | [Query-first modeling in Cassandra](02-cassandra-data-modeling/) | partition/clustering keys, one table per question, time buckets | Docker (Cassandra) |
| 03 | [Cloud warehouse on Redshift](03-redshift-warehouse/) | S3 → `COPY` → staging → star schema (ELT), dist/sort keys, Terraform | AWS |
| 04 | [Data lake with Spark](04-spark-data-lake/) | PySpark, schemas, quarantine, partitioned Parquet, EMR Serverless, Glue + Athena | local or AWS |
| 05 | [Orchestration with Airflow 3](05-airflow-pipelines/) | DAGs, custom operators, backfills, TaskFlow, dynamic task mapping, DAG tests | Docker (Airflow) |
| 06 | [API → Postgres ingestion](06-api-to-postgres/) | retries/backoff, response validation, upserts, run audit table | local |

## The shared dataset

*Sparkify* is a fictional music-streaming startup. `shared/generate_sample_data.py`
writes a deterministic, synthetic dataset in the same shape as the classic
"Million Song Dataset + event simulator" data used in many courses:

```
data/
├── song_data/A/B/C/TRABC….json          # one song + artist per file (catalog)
└── log_data/2026/09/2026-09-01-events.json   # JSON Lines, one app event per line
```

It deliberately includes real-world mess: plays of songs missing from the catalog,
logged-out events with no user id, users upgrading from free to paid mid-week,
duplicate events, empty locations, and names with apostrophes and accents.

```bash
python shared/generate_sample_data.py                 # 400 songs, ~5k events, 7 days
python shared/generate_sample_data.py --days 30 --users 300   # bigger
```

With the default seed every project produces the **same answer: 3,802 song plays,
2,756 of them matched to the catalog.** That cross-check is a handy test when you
change something.

The weather project (06) uses live data from the free
[Open-Meteo API](https://open-meteo.com/en/docs) instead.

## How the projects relate

```
                       shared/generate_sample_data.py
                                    │  raw JSON (data/)
         ┌──────────────┬───────────┼──────────────┬─────────────────┐
         ▼              ▼           ▼              ▼                 ▼
   01 Postgres     02 Cassandra   03 S3 → Redshift  04 S3 → Spark → S3   05 Airflow
   (Python ETL)    (query tables) (SQL ELT)         (Parquet lake)       orchestrates 01-style
                                                                         loads, 03's SQL and 06
   06 Open-Meteo API ──► Postgres  ◄───────────────────────────────────────────┘
```

Suggested order: **01 → 02 → 06 → 05 → 04 → 03**. The first four run entirely on
your machine; 03 and 04 need an AWS account.

## Quick start

Requirements: Python 3.11+, Docker with Compose v2. Java 17/21 for project 04.
Terraform ≥ 1.11 and the AWS CLI v2 for the cloud projects.

```bash
git clone <this repo> && cd data-engineering-projects
python -m venv .venv && source .venv/bin/activate
pip install -r requirements-dev.txt

make data          # generate ./data
make up            # Postgres (5432) + Cassandra (9042) in Docker
make test          # unit tests for all projects, no DB or cloud needed
```

Then follow the README inside each project folder. Every project has its own
`requirements.txt` if you prefer one virtualenv per project.

| Service | Where | Credentials |
|---|---|---|
| Postgres 17 | `localhost:5432`, databases `sparkify`, `sparkify_airflow`, `weather` | `student` / `student` |
| Cassandra 5 | `localhost:9042`, keyspace `sparkify` | none |
| Airflow 3.3 UI | <http://localhost:8080> (project 05) | `airflow` / `airflow` |

## Conventions used throughout

- **Idempotent loads.** Every pipeline can be re-run safely: upserts in Postgres,
  anti-joins in Redshift, natural primary keys in Cassandra, dynamic partition
  overwrite in Spark. Re-running is how you recover from failures, so it must be safe.
- **Pure transforms, thin I/O.** Cleaning logic lives in functions that take data
  and return data (`transforms.py`, `model.py`, `weather.py`, Spark functions), so
  it's unit-tested without a database. Scripts just wire them to storage.
- **Data quality checks** at the end of every load, failing loudly.
- **No secrets in code.** Local defaults match `docker-compose.yml`; cloud passwords
  come from environment variables; AWS access uses IAM roles, never keys in SQL.
- **Comments explain *why*.** The SQL and code are written to be read.

## Repository layout

```
.
├── shared/generate_sample_data.py   # synthetic Sparkify dataset
├── docker-compose.yml               # Postgres + Cassandra for local work
├── docker/postgres/init/            # creates the extra Postgres databases
├── 01-postgres-song-etl/
├── 02-cassandra-data-modeling/
├── 03-redshift-warehouse/           # infra/ = Terraform
├── 04-spark-data-lake/              # infra/ = Terraform, scripts/ = EMR helpers
├── 05-airflow-pipelines/            # own docker-compose.yaml, dags/, plugins/
├── 06-api-to-postgres/
├── Makefile                         # make data | up | down | test | lint
├── pyproject.toml                   # ruff + pytest settings
└── requirements-dev.txt
```

## Cloud costs

Projects 03 and 04 create real AWS resources. Both use serverless, pay-per-use
services (Redshift Serverless, EMR Serverless, Athena) with hard caps in Terraform
(RPU-hour usage limit, max vCPU/memory, auto-stop), and S3 buckets set to
`force_destroy` so `terraform destroy` removes everything. Check current AWS pricing
for your region, and **run `terraform destroy` when you're done.**

## Versions this was written against (October 2026)

Python 3.11–3.13 · Postgres 17 · Cassandra 5.0 · Apache Airflow 3.3.2 ·
PySpark 3.5.8 (matching EMR Serverless `emr-7.14.0`) · Terraform AWS provider 6.x ·
psycopg 3 · cassandra-driver 3.29+ · redshift-connector 2.x
