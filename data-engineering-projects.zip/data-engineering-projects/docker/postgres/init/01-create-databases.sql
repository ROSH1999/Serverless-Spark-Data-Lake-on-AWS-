-- Runs once, the first time the Postgres container starts with an empty volume.
-- The default database "sparkify" (project 01) is created by POSTGRES_DB.

CREATE DATABASE sparkify_airflow;  -- project 05: tables loaded by Airflow DAGs
CREATE DATABASE weather;           -- project 06 (and the weather DAG in 05)
