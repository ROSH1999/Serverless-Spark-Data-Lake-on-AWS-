"""Generate a realistic, synthetic music-streaming dataset.

Every project in this repo starts from the same raw data, so you can compare how
Postgres, Cassandra, Redshift, Spark and Airflow each handle it.

Two datasets are written, mimicking what a streaming startup would actually have:

1. **Song catalog** (``song_data/``) – one JSON document per track, nested in
   folders by the 3rd/4th/5th character of the track id. This is the layout of
   the public "Million Song Dataset" subset that many tutorials use.

       data/song_data/A/B/C/TRABC....json

2. **User activity logs** (``log_data/``) – one JSON-Lines file per day, written
   by an app event collector. Each line is one user action (play a song, log in,
   visit settings, ...).

       data/log_data/2026/09/2026-09-01-events.json

The generator deliberately includes the messiness you meet in real pipelines:

* plays of songs that are *not* in the catalog (so joins don't always match)
* logged-out events with an empty ``userId``
* users upgrading from ``free`` to ``paid`` mid-week (slowly changing dims)
* a small number of exact duplicate events (at-least-once delivery)
* artists with no location / coordinates
* names and titles with apostrophes and accents (quoting bugs!)

Usage::

    python shared/generate_sample_data.py                     # defaults
    python shared/generate_sample_data.py --days 14 --users 80
    python shared/generate_sample_data.py --out /tmp/data --seed 7
"""

from __future__ import annotations

import argparse
import json
import random
import string
from dataclasses import dataclass
from datetime import date, datetime, timedelta, timezone
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parents[1]

# --- word lists used to invent artists, songs and people --------------------

ADJECTIVES = [
    "Midnight", "Electric", "Golden", "Velvet", "Broken", "Silver", "Neon",
    "Quiet", "Wild", "Hollow", "Crimson", "Paper", "Northern", "Lucky",
    "Lonely", "Restless", "Café", "Sunday", "Static", "Distant",
]
NOUNS = [
    "Hearts", "Rivers", "Engines", "Lanterns", "Wolves", "Satellites",
    "Echoes", "Highways", "Gardens", "Machines", "Shadows", "Tides",
    "Avenues", "Comets", "Mirrors", "Harbors", "Radios", "Fireflies",
]
SONG_WORDS = [
    "Love", "Summer", "Rain", "Fire", "Home", "Dancing", "Gone", "Tonight",
    "Forever", "City", "Dreams", "Ocean", "Light", "Running", "Heartbeat",
    "Gravity", "Window", "Letters", "Morning", "Stranger", "Sugar", "Thunder",
]
SONG_TEMPLATES = [
    "{a} {b}", "{a} in the {b}", "Don't Stop the {b}", "{a} & {b}",
    "The {a} {b}", "{b} (Remastered)", "{a} {b} - Live", "Señorita {b}",
]
FIRST_NAMES = [
    "Lily", "Jacob", "Kate", "Ryan", "Chloe", "Aleena", "Tegan", "Jayden",
    "Matthew", "Ava", "Noah", "Sofia", "Wyatt", "Layla", "Mohammad", "Kinsley",
    "Rylan", "Emily", "Zoé", "Jordan", "Priya", "Mateo", "Hana", "Liam",
]
LAST_NAMES = [
    "Koch", "Smith", "Harrell", "Fox", "Cuevas", "Kirby", "Levine", "Graves",
    "Jones", "O'Brien", "Nguyen", "Garcia", "Haynes", "Patel", "Müller",
    "Robinson", "Kim", "Olsen", "D'Souza", "Walker",
]
LOCATIONS = [
    ("San Francisco-Oakland-Hayward, CA", 37.77, -122.42),
    ("New York-Newark-Jersey City, NY-NJ-PA", 40.71, -74.01),
    ("Chicago-Naperville-Elgin, IL-IN-WI", 41.88, -87.63),
    ("Atlanta-Sandy Springs-Roswell, GA", 33.75, -84.39),
    ("Seattle-Tacoma-Bellevue, WA", 47.61, -122.33),
    ("Austin-Round Rock, TX", 30.27, -97.74),
    ("Portland-South Portland, ME", 43.66, -70.26),
    ("Lansing-East Lansing, MI", 42.73, -84.56),
    ("Houston-The Woodlands-Sugar Land, TX", 29.76, -95.37),
    ("Miami-Fort Lauderdale-West Palm Beach, FL", 25.76, -80.19),
]
ARTIST_LOCATIONS = [
    ("London, England", 51.50632, -0.12714),
    ("Nashville, TN", 36.16778, -86.77836),
    ("Los Angeles, CA", 34.05349, -118.24532),
    ("Detroit, MI", 42.33168, -83.04792),
    ("Toronto, Ontario, Canada", 43.64856, -79.38533),
    ("Kingston, Jamaica", 17.99702, -76.79358),
    ("Stockholm, Sweden", 59.32893, 18.06491),
    ("Rio de Janeiro, Brazil", -22.97673, -43.19508),
    ("Seoul, South Korea", 37.56654, 126.97797),
]
USER_AGENTS = [
    '"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_4) AppleWebKit/537.36 '
    '(KHTML, like Gecko) Chrome/36.0.1985.143 Safari/537.36"',
    '"Mozilla/5.0 (Windows NT 6.1; WOW64; rv:31.0) Gecko/20100101 Firefox/31.0"',
    '"Mozilla/5.0 (iPhone; CPU iPhone OS 7_1_2 like Mac OS X) AppleWebKit/537.51.2 '
    '(KHTML, like Gecko) Version/7.0 Mobile/11D257 Safari/9537.53"',
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) "
    "Ubuntu Chromium/36.0.1985.125 Chrome/36.0.1985.125 Safari/537.36",
    '"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 '
    '(KHTML, like Gecko) Chrome/120.0 Safari/537.36"',
]
# (page, weight). NextSong dominates, like a real streaming service.
BROWSING_PAGES = [
    ("Home", 10), ("Thumbs Up", 6), ("Add to Playlist", 3), ("Thumbs Down", 2),
    ("Settings", 1), ("Help", 1), ("About", 1), ("Error", 0.3),
]


@dataclass
class Song:
    song_id: str
    title: str
    artist_id: str
    artist_name: str
    duration: float
    year: int


@dataclass
class User:
    user_id: int
    first_name: str
    last_name: str
    gender: str
    level: str
    location: str
    user_agent: str
    registration: float
    upgrades_on: date | None


def _rand_id(rng: random.Random, prefix: str) -> str:
    alphabet = string.ascii_uppercase + string.digits
    return prefix + "".join(rng.choice(alphabet) for _ in range(16))


def _song_title(rng: random.Random) -> str:
    return rng.choice(SONG_TEMPLATES).format(
        a=rng.choice(ADJECTIVES + SONG_WORDS), b=rng.choice(SONG_WORDS + NOUNS)
    )


def build_catalog(rng: random.Random, n_artists: int, n_songs: int) -> tuple[list[dict], list[Song]]:
    """Return (raw song documents, Song objects)."""
    artists = []
    used_names = set()
    while len(artists) < n_artists:
        name = f"{rng.choice(['The ', '', '', 'DJ '])}{rng.choice(ADJECTIVES)} {rng.choice(NOUNS)}".strip()
        if name in used_names:
            continue
        used_names.add(name)
        if rng.random() < 0.4:  # many artists have no known location
            loc, lat, lon = "", None, None
        else:
            loc, lat, lon = rng.choice(ARTIST_LOCATIONS)
        artists.append(
            {"artist_id": _rand_id(rng, "AR"), "artist_name": name,
             "artist_location": loc, "artist_latitude": lat, "artist_longitude": lon}
        )

    docs, songs = [], []
    for _ in range(n_songs):
        artist = rng.choice(artists)
        song = Song(
            song_id=_rand_id(rng, "SO"),
            title=_song_title(rng),
            artist_id=artist["artist_id"],
            artist_name=artist["artist_name"],
            duration=round(rng.uniform(95, 430), 5),
            year=0 if rng.random() < 0.3 else rng.randint(1965, 2025),  # 0 = unknown
        )
        songs.append(song)
        docs.append(
            {"num_songs": 1, **artist, "song_id": song.song_id, "title": song.title,
             "duration": song.duration, "year": song.year}
        )
    return docs, songs


def build_users(rng: random.Random, n_users: int, start: date, days: int) -> list[User]:
    users = []
    for user_id in range(1, n_users + 1):
        level = "paid" if rng.random() < 0.35 else "free"
        upgrades_on = None
        if level == "free" and rng.random() < 0.25:
            upgrades_on = start + timedelta(days=rng.randint(1, max(1, days - 1)))
        reg = datetime.combine(start, datetime.min.time(), tzinfo=timezone.utc) - timedelta(
            days=rng.randint(30, 900)
        )
        users.append(
            User(
                user_id=user_id,
                first_name=rng.choice(FIRST_NAMES),
                last_name=rng.choice(LAST_NAMES),
                gender=rng.choice("MF"),
                level=level,
                location=rng.choice(LOCATIONS)[0],
                user_agent=rng.choice(USER_AGENTS),
                registration=float(int(reg.timestamp() * 1000)),
                upgrades_on=upgrades_on,
            )
        )
    return users


def _event(user: User | None, *, page: str, ts: int, session_id: int, item: int,
           level: str, song: tuple | None = None, status: int = 200) -> dict:
    logged_in = user is not None and page != "Login"
    return {
        "artist": song[1] if song else None,
        "auth": "Logged In" if logged_in else "Logged Out",
        "firstName": user.first_name if logged_in else None,
        "gender": user.gender if logged_in else None,
        "itemInSession": item,
        "lastName": user.last_name if logged_in else None,
        "length": song[2] if song else None,
        "level": level,
        "location": user.location if logged_in else None,
        "method": "PUT" if page in {"NextSong", "Login", "Logout", "Submit Upgrade"} else "GET",
        "page": page,
        "registration": user.registration if logged_in else None,
        "sessionId": session_id,
        "song": song[0] if song else None,
        "status": status,
        "ts": ts,
        "userAgent": user.user_agent if logged_in else None,
        "userId": str(user.user_id) if logged_in else "",
    }


def build_day(rng: random.Random, day: date, users: list[User], songs: list[Song],
              session_counter: list[int]) -> list[dict]:
    """Simulate one day of app activity."""
    events: list[dict] = []
    day_start = datetime.combine(day, datetime.min.time(), tzinfo=timezone.utc)
    popular = songs[: max(5, len(songs) // 10)]  # a head of popular songs

    for user in users:
        if rng.random() < 0.35:  # not every user is active every day
            continue
        upgrading_today = user.upgrades_on == day
        level = "paid" if user.level == "paid" or (user.upgrades_on and day > user.upgrades_on) else "free"
        for _ in range(rng.choice([1, 1, 1, 2])):
            session_counter[0] += 1
            session_id = session_counter[0]
            ts = day_start + timedelta(seconds=rng.randint(0, 22 * 3600))
            item = 0

            def ms(t: datetime) -> int:
                return int(t.timestamp() * 1000)

            # Some sessions begin logged-out (Home -> Login), as real web apps do.
            if rng.random() < 0.2:
                events.append(_event(None, page="Home", ts=ms(ts), session_id=session_id, item=item, level=level))
                item += 1
                ts += timedelta(seconds=rng.randint(5, 40))
                events.append(_event(user, page="Login", ts=ms(ts), session_id=session_id, item=item, level=level))
                item += 1
                ts += timedelta(seconds=rng.randint(5, 20))

            for n in range(rng.randint(3, 30)):
                # A free user who upgrades today does so a few actions into the session;
                # every later event carries level=paid (a slowly changing attribute).
                if upgrading_today and level == "free" and n == 2:
                    events.append(_event(user, page="Submit Upgrade", ts=ms(ts), session_id=session_id,
                                         item=item, level="free", status=307))
                    item += 1
                    ts += timedelta(seconds=rng.randint(5, 30))
                    level = "paid"

                if rng.random() < 0.78:
                    if rng.random() < 0.72:
                        s = rng.choice(popular) if rng.random() < 0.4 else rng.choice(songs)
                        song = (s.title, s.artist_name, s.duration)
                    else:
                        # a play the catalog doesn't know about
                        song = (_song_title(rng), f"{rng.choice(ADJECTIVES)} {rng.choice(NOUNS)}",
                                round(rng.uniform(95, 430), 5))
                    events.append(_event(user, page="NextSong", ts=ms(ts), session_id=session_id,
                                         item=item, level=level, song=song))
                    ts += timedelta(seconds=int(song[2]))
                else:
                    pages, weights = zip(*BROWSING_PAGES)
                    page = rng.choices(pages, weights=weights)[0]
                    events.append(_event(user, page=page, ts=ms(ts), session_id=session_id, item=item,
                                         level=level, status=404 if page == "Error" else 200))
                    ts += timedelta(seconds=rng.randint(3, 60))
                item += 1

                # duplicate delivery from the event collector (~0.5%)
                if rng.random() < 0.005:
                    events.append(dict(events[-1]))

            if rng.random() < 0.3:
                events.append(_event(user, page="Logout", ts=int(ts.timestamp() * 1000),
                                     session_id=session_id, item=item, level=level, status=307))

    events.sort(key=lambda e: e["ts"])
    return events


def write_dataset(out: Path, *, seed: int, start: date, days: int, n_users: int,
                  n_artists: int, n_songs: int) -> dict:
    rng = random.Random(seed)
    song_docs, songs = build_catalog(rng, n_artists, n_songs)
    users = build_users(rng, n_users, start, days)

    song_dir, log_dir = out / "song_data", out / "log_data"
    for doc in song_docs:
        track_id = _rand_id(rng, "TR")
        path = song_dir / track_id[2] / track_id[3] / track_id[4] / f"{track_id}.json"
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(doc, ensure_ascii=False))

    session_counter = [0]
    n_events = 0
    for offset in range(days):
        day = start + timedelta(days=offset)
        events = build_day(rng, day, users, songs, session_counter)
        path = log_dir / f"{day:%Y}" / f"{day:%m}" / f"{day:%Y-%m-%d}-events.json"
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open("w", encoding="utf-8") as fh:
            for e in events:
                fh.write(json.dumps(e, ensure_ascii=False) + "\n")
        n_events += len(events)

    return {"songs": len(song_docs), "users": len(users), "days": days, "events": n_events}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--out", type=Path, default=REPO_ROOT / "data", help="output folder (default: ./data)")
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--start", type=date.fromisoformat, default=date(2026, 9, 1),
                        help="first day of activity logs, YYYY-MM-DD (default 2026-09-01)")
    parser.add_argument("--days", type=int, default=7)
    parser.add_argument("--users", type=int, default=50)
    parser.add_argument("--artists", type=int, default=60)
    parser.add_argument("--songs", type=int, default=400)
    args = parser.parse_args()

    if (args.out / "song_data").exists() or (args.out / "log_data").exists():
        raise SystemExit(f"{args.out} already contains data. Delete song_data/ and log_data/ first.")

    stats = write_dataset(args.out, seed=args.seed, start=args.start, days=args.days,
                          n_users=args.users, n_artists=args.artists, n_songs=args.songs)
    print(f"Wrote {stats['songs']} songs and {stats['events']} events "
          f"({stats['days']} days, {stats['users']} users) to {args.out}")


if __name__ == "__main__":
    main()
